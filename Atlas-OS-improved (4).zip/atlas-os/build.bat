@echo off
echo ============================================
echo   Atlas OS Build Script
echo ============================================

set "BASE_DIR=%~dp0"
set "PYO3_USE_ABI3_FORWARD_COMPATIBILITY=1"

echo.
echo [1/4] Installing Python dependencies...
cd /d "%BASE_DIR%backend"
pip install -r requirements.txt
if errorlevel 1 goto fail

echo.
echo [2/4] Building frontend...
cd /d "%BASE_DIR%frontend"
call npm install
if errorlevel 1 goto fail
call npm run build
if errorlevel 1 goto fail

echo.
echo [3/4] Building executable...
cd /d "%BASE_DIR%desktop"
pip install pyinstaller pywebview
if errorlevel 1 goto fail
pyinstaller build.spec
if errorlevel 1 goto fail

echo.
echo [4/4] Build complete!
echo Executable: %BASE_DIR%desktop\dist\Atlas-OS.exe
goto end

:fail
echo.
echo BUILD FAILED! Check output above.
pause
exit /b 1

:end
echo.
echo Done!
pause
