"""Ollama Async Client"""
import httpx
from typing import AsyncGenerator, Dict, Any, List
from atlas.config import OLLAMA_HOST

class OllamaClient:
    def __init__(self, host: str = OLLAMA_HOST):
        self.host = host.rstrip("/")
        self.client = httpx.AsyncClient(timeout=120.0)

    async def list_models(self) -> List[Dict[str, Any]]:
        try:
            resp = await self.client.get(f"{self.host}/api/tags")
            data = resp.json()
            return data.get("models", [])
        except Exception:
            return []

    async def generate(self, model: str, prompt: str, system: str = "", stream: bool = False, temperature: float = 0.7) -> Dict[str, Any]:
        payload = {"model": model, "prompt": prompt, "system": system, "stream": stream, "options": {"temperature": temperature}}
        resp = await self.client.post(f"{self.host}/api/generate", json=payload)
        return resp.json()

    async def chat(self, model: str, messages: List[Dict[str, str]], stream: bool = False, temperature: float = 0.7) -> Dict[str, Any]:
        payload = {"model": model, "messages": messages, "stream": stream, "options": {"temperature": temperature}}
        resp = await self.client.post(f"{self.host}/api/chat", json=payload)
        return resp.json()

    async def stream_generate(self, model: str, prompt: str, system: str = "", temperature: float = 0.7) -> AsyncGenerator[str, None]:
        payload = {"model": model, "prompt": prompt, "system": system, "stream": True, "options": {"temperature": temperature}}
        async with self.client.stream("POST", f"{self.host}/api/generate", json=payload) as resp:
            async for line in resp.aiter_lines():
                if line.strip():
                    import json
                    try:
                        data = json.loads(line)
                        yield data.get("response", "")
                    except json.JSONDecodeError:
                        pass

client = OllamaClient()
