"""Model Registry"""
from typing import List, Dict, Any

MODELS: List[Dict[str, Any]] = [
    {"id": "llama3.2", "name": "Llama 3.2", "size": "small", "parameters": "3B", "required_ram_mb": 4000, "required_vram_mb": 0, "capabilities": ["chat", "coding", "analysis"], "description": "Lightweight general-purpose model from Meta.", "tags": ["meta", "general"], "context_length": 128000, "recommended_temperature": 0.7},
    {"id": "qwen2.5", "name": "Qwen 2.5", "size": "medium", "parameters": "7B", "required_ram_mb": 8000, "required_vram_mb": 0, "capabilities": ["chat", "coding", "math", "analysis"], "description": "Strong multilingual model from Alibaba.", "tags": ["alibaba", "multilingual"], "context_length": 128000, "recommended_temperature": 0.7},
    {"id": "mistral", "name": "Mistral", "size": "medium", "parameters": "7B", "required_ram_mb": 8000, "required_vram_mb": 0, "capabilities": ["chat", "coding", "reasoning"], "description": "Efficient and powerful model from Mistral AI.", "tags": ["mistral", "efficient"], "context_length": 32768, "recommended_temperature": 0.7},
    {"id": "deepseek-coder-v2", "name": "DeepSeek Coder V2", "size": "medium", "parameters": "16B", "required_ram_mb": 16000, "required_vram_mb": 0, "capabilities": ["coding", "analysis", "chat"], "description": "Specialized coding model from DeepSeek.", "tags": ["deepseek", "coding"], "context_length": 128000, "recommended_temperature": 0.3},
    {"id": "llama3.1:70b", "name": "Llama 3.1 70B", "size": "large", "parameters": "70B", "required_ram_mb": 48000, "required_vram_mb": 48000, "capabilities": ["chat", "coding", "analysis", "reasoning", "research"], "description": "Top-tier large model from Meta.", "tags": ["meta", "large"], "context_length": 128000, "recommended_temperature": 0.7},
]

def get_all_models() -> List[Dict[str, Any]]:
    return MODELS

def get_model_by_id(model_id: str) -> Dict[str, Any] | None:
    for m in MODELS:
        if m["id"] == model_id:
            return m
    return None
