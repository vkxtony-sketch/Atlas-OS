"""Model Router"""
from typing import Dict, Any, List
from atlas.models.registry import get_all_models
from atlas.hardware import detector

class ModelRouter:
    def get_recommendations(self) -> List[Dict[str, Any]]:
        profile = detector.get_profile()
        ram_mb = profile["ram"]["total_mb"]
        vram_mb = profile["gpu"]["total_vram_mb"]
        models = get_all_models()
        recommendations = []
        for m in models:
            can_run = ram_mb >= m["required_ram_mb"] and vram_mb >= m["required_vram_mb"]
            recommendations.append({"id": m["id"], "name": m["name"], "can_run": can_run, "required_ram_mb": m["required_ram_mb"], "required_vram_mb": m["required_vram_mb"]})
        return recommendations

    def recommend_for_task(self, task: str) -> str:
        task_lower = task.lower()
        if "code" in task_lower or "program" in task_lower or "debug" in task_lower:
            return "deepseek-coder-v2"
        if "math" in task_lower or "calculate" in task_lower:
            return "qwen2.5"
        if "research" in task_lower or "analyze" in task_lower:
            return "mistral"
        return "llama3.2"

router = ModelRouter()
