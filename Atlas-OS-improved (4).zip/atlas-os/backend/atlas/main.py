"""Atlas OS FastAPI Entry Point"""
import asyncio
from contextlib import asynccontextmanager
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import os

from atlas import config
from atlas.config import BASE_DIR
from atlas.api.auth import require_api_key
from atlas.api.rate_limit import RateLimitMiddleware
from atlas.api.routes import hardware, agents, projects, chat, models, knowledge, memory

@asynccontextmanager
async def lifespan(app: FastAPI):
    print(f"{config.BRAND_NAME} starting...")
    if not config.AUTH_ENABLED:
        print("WARNING: ATLAS_AUTH_ENABLED=false -- API is unauthenticated.")
    yield
    print(f"{config.BRAND_NAME} shutting down...")

app = FastAPI(
    title=config.BRAND_NAME,
    description=config.BRAND_TAGLINE,
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(RateLimitMiddleware)

# Every /api/v1/* route requires a valid API key (unless ATLAS_AUTH_ENABLED=false).
# The frontend's static build and /health stay open so the local UI keeps working
# without you having to paste a key into the browser.
auth_dep = [Depends(require_api_key)]

app.include_router(hardware.router, prefix="/api/v1/hardware", dependencies=auth_dep)
app.include_router(agents.router, prefix="/api/v1/agents", dependencies=auth_dep)
app.include_router(projects.router, prefix="/api/v1/projects", dependencies=auth_dep)
app.include_router(chat.router, prefix="/api/v1/chat", dependencies=auth_dep)
app.include_router(models.router, prefix="/api/v1/models", dependencies=auth_dep)
app.include_router(knowledge.router, prefix="/api/v1/knowledge", dependencies=auth_dep)
app.include_router(memory.router, prefix="/api/v1/memory", dependencies=auth_dep)

@app.get("/health")
async def health():
    return {"status": "ok", "version": "1.0.0", "brand": config.BRAND_NAME}

frontend_dist = BASE_DIR.parent / "frontend" / "dist"
if frontend_dist.exists():
    app.mount("/", StaticFiles(directory=str(frontend_dist), html=True), name="static")

@app.get("/")
async def root():
    index = frontend_dist / "index.html"
    if index.exists():
        return FileResponse(str(index))
    return {"message": "Atlas OS API is running. Build the frontend to see the UI."}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("atlas.main:app", host="127.0.0.1", port=8472, log_level="info")
