"""API Key Authentication

Protects the branded API with a simple bearer-token scheme. Keys can come
from either the ATLAS_API_KEYS env var (comma-separated) or a plain-text
file (one key per line) at data/api_keys.txt -- generate keys into that
file with `python scripts/generate_api_key.py`.

This is deliberately simple (no OAuth, no external identity provider)
because it's meant for a single self-hosted box serving a handful of
clients/apps you control, not a multi-tenant SaaS. If you outgrow that,
swap this module out rather than bolting more onto it.
"""
import os
import secrets
from pathlib import Path
from typing import Optional

from fastapi import Header, HTTPException, status

from atlas import config


def _load_keys_from_file() -> set:
    path = Path(config.API_KEYS_FILE)
    if not path.exists():
        return set()
    with open(path, "r") as f:
        return {line.strip() for line in f if line.strip() and not line.startswith("#")}


def _load_keys_from_env() -> set:
    if not config.API_KEYS_ENV:
        return set()
    return {k.strip() for k in config.API_KEYS_ENV.split(",") if k.strip()}


def get_valid_keys() -> set:
    """Re-reads keys on every call (cheap for a text file) so newly
    generated keys work without restarting the server."""
    return _load_keys_from_env() | _load_keys_from_file()


def generate_key(prefix: str = "atlas") -> str:
    """Create a new API key and persist it to the keys file."""
    new_key = f"{prefix}_{secrets.token_urlsafe(24)}"
    path = Path(config.API_KEYS_FILE)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a") as f:
        f.write(new_key + "\n")
    return new_key


async def require_api_key(authorization: Optional[str] = Header(default=None)) -> str:
    """FastAPI dependency: validates `Authorization: Bearer <key>`.

    Raises 401 if auth is enabled and the key is missing/invalid. When
    ATLAS_AUTH_ENABLED=false this becomes a no-op (useful for pure local
    dev), returning a placeholder identity.
    """
    if not config.AUTH_ENABLED:
        return "anonymous-local"

    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing or malformed Authorization header. Expected: Bearer <api_key>",
        )

    key = authorization.removeprefix("Bearer ").strip()
    valid_keys = get_valid_keys()

    if not valid_keys:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=(
                "No API keys configured yet. Run scripts/generate_api_key.py "
                "to create one, or set ATLAS_AUTH_ENABLED=false for local dev."
            ),
        )

    if key not in valid_keys:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key")

    return key
