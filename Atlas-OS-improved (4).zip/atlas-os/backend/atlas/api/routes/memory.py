"""Memory Routes

Exposes the memory system (atlas/core/memory.py) for direct inspection and
editing: global user preferences, and per-project history/architecture
notes. Atlas reads and writes these automatically during goal execution;
these routes are for you to view, correct, or seed them directly (e.g.
setting a preference once instead of repeating it in every goal, or
recording a decision Atlas wasn't involved in).
"""
from fastapi import APIRouter

from atlas.core.memory import memory

router = APIRouter()


@router.get("/preferences")
async def list_preferences():
    return {"success": True, "preferences": await memory.all_preferences()}


@router.post("/preferences")
async def set_preference(body: dict):
    key = str(body.get("key", "")).strip()
    value = body.get("value")
    if not key or value is None:
        return {"success": False, "error": "Both 'key' and 'value' are required."}
    await memory.set_preference(key, str(value))
    return {"success": True}


@router.delete("/preferences/{key}")
async def delete_preference(key: str):
    deleted = await memory.delete_preference(key)
    return {"success": deleted, "error": None if deleted else "Preference not found"}


@router.get("/projects/{project_id}/history")
async def get_project_history(project_id: str, event_type: str | None = None, limit: int = 50):
    history = await memory.get_history(project_id, event_type=event_type, limit=limit)
    return {"success": True, "history": history}


@router.post("/projects/{project_id}/history")
async def add_project_history(project_id: str, body: dict):
    event_type = str(body.get("event_type", "note")).strip() or "note"
    summary = str(body.get("summary", "")).strip()
    if not summary:
        return {"success": False, "error": "'summary' is required."}
    event_id = await memory.record_event(project_id, event_type, summary, body.get("metadata"))
    return {"success": True, "event_id": event_id}


@router.delete("/history/{event_id}")
async def delete_history_event(event_id: str):
    deleted = await memory.delete_event(event_id)
    return {"success": deleted, "error": None if deleted else "Event not found"}
