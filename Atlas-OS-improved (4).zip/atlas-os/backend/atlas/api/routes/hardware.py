"""Hardware Routes"""
from fastapi import APIRouter
from atlas.hardware import detector

router = APIRouter()

@router.get("/profile")
async def get_profile():
    return {"success": True, "profile": detector.get_profile()}

@router.get("/resources")
async def get_resources():
    return {"success": True, "resources": detector.get_resources()}
