"""Knowledge Routes"""
from fastapi import APIRouter
from atlas.knowledge_base.chroma_store import store
from atlas.knowledge_base.indexer import indexer

router = APIRouter()

@router.post("/search")
async def search(body: dict):
    results = store.search(body.get("query", ""), body.get("top_k", 5))
    return {"success": True, "results": results}

@router.get("/stats")
async def get_stats():
    return {"success": True, "stats": store.get_stats()}

@router.post("/index")
async def index_document(body: dict):
    if "text" in body:
        doc_id = indexer.index_text(body["text"], body.get("metadata"))
        return {"success": True, "doc_id": doc_id}
    elif "filepath" in body:
        doc_id = indexer.index_file(body["filepath"])
        return {"success": True, "doc_id": doc_id}
    return {"success": False, "error": "No text or filepath provided"}
