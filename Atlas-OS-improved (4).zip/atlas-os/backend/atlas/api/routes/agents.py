"""Agents Routes"""
import json

from fastapi import APIRouter
from fastapi.responses import StreamingResponse

from atlas.agents.base import get_agent, list_all_agents
from atlas.api.routes.projects import get_project_directory
from atlas.core.workflow import orchestrator

router = APIRouter()


@router.get("/list")
async def list_agents():
    return {"success": True, "agents": list_all_agents()}


@router.get("/{name}/status")
async def get_status(name: str):
    agent = get_agent(name)
    if not agent:
        return {"success": False, "error": "Agent not found"}
    return {"success": True, "status": agent.status}


@router.post("/{name}/execute")
async def execute_agent(name: str, body: dict):
    agent = get_agent(name)
    if not agent:
        return {"success": False, "error": "Agent not found"}

    workspace_dir = body.get("workspace_dir")
    project_id = body.get("project_id")
    if not workspace_dir and project_id:
        workspace_dir = await get_project_directory(project_id)

    result = await agent.execute(body.get("task", ""), body.get("context", ""), workspace_dir=workspace_dir)
    return result


@router.get("/executive/goal")
async def process_goal(goal: str, project_id: str | None = None, clarifications: str | None = None):
    """Runs a goal end-to-end via the orchestrator, streamed as SSE.

    If Atlas decides it needs more information first, the stream ends early
    with a `clarification_needed` event containing a list of questions and
    no `complete` event. Re-call this same endpoint with the same `goal`
    plus a `clarifications` query param -- a JSON object mapping each
    question to the user's answer, e.g.
    `clarifications={"What language?": "Python"}` -- to resume with that
    context folded in.
    """
    workspace_dir = await get_project_directory(project_id) if project_id else None

    parsed_clarifications = None
    if clarifications:
        try:
            parsed_clarifications = json.loads(clarifications)
        except json.JSONDecodeError:
            parsed_clarifications = None

    async def event_stream():
        async for event in orchestrator.execute_goal(
            goal, workspace_dir=workspace_dir, clarifications=parsed_clarifications, project_id=project_id
        ):
            yield f"data: {json.dumps(event)}\n\n"
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")
