"""Projects Routes"""
import datetime
import uuid
from pathlib import Path

import aiosqlite
from fastapi import APIRouter

from atlas.config import DB_PATH, WORKSPACE_DIR

router = APIRouter()


async def get_db():
    db = await aiosqlite.connect(DB_PATH)
    await db.execute(
        "CREATE TABLE IF NOT EXISTS projects ("
        "id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT, goal TEXT, "
        "status TEXT DEFAULT 'active', created_at TEXT, updated_at TEXT, directory TEXT)"
    )
    await db.commit()
    return db


def _row_to_project(row) -> dict:
    return {
        "id": row[0],
        "name": row[1],
        "description": row[2],
        "goal": row[3],
        "status": row[4],
        "created_at": row[5],
        "updated_at": row[6],
        "directory": row[7],
    }


async def get_project_directory(project_id: str) -> str | None:
    """Look up a project's sandboxed workspace directory by id."""
    db = await get_db()
    async with db.execute("SELECT directory FROM projects WHERE id = ?", (project_id,)) as cursor:
        row = await cursor.fetchone()
    await db.close()
    return row[0] if row else None


@router.get("/list")
async def list_projects():
    db = await get_db()
    async with db.execute("SELECT * FROM projects ORDER BY created_at DESC") as cursor:
        rows = await cursor.fetchall()
    await db.close()
    return {"success": True, "projects": [_row_to_project(r) for r in rows]}


@router.get("/{project_id}")
async def get_project(project_id: str):
    db = await get_db()
    async with db.execute("SELECT * FROM projects WHERE id = ?", (project_id,)) as cursor:
        row = await cursor.fetchone()
    await db.close()
    if not row:
        return {"success": False, "error": "Project not found"}
    return {"success": True, "project": _row_to_project(row)}


@router.post("/create")
async def create_project(body: dict):
    pid = str(uuid.uuid4())
    now = datetime.datetime.now().isoformat()

    workspace = Path(WORKSPACE_DIR) / pid
    workspace.mkdir(parents=True, exist_ok=True)

    db = await get_db()
    await db.execute(
        "INSERT INTO projects (id, name, description, goal, created_at, updated_at, directory) "
        "VALUES (?, ?, ?, ?, ?, ?, ?)",
        (pid, body.get("name", ""), body.get("description", ""), body.get("goal", ""), now, now, str(workspace)),
    )
    await db.commit()
    await db.close()
    return {"success": True, "project_id": pid, "directory": str(workspace)}
