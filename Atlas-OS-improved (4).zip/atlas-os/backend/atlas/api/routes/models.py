"""Models Routes"""
from fastapi import APIRouter
from atlas.models.registry import get_all_models
from atlas.models.router import router as model_router
from atlas.models.ollama_client import client

router = APIRouter()

@router.get("/registry")
async def get_registry():
    return {"success": True, "models": get_all_models()}

@router.get("/available")
async def get_available():
    try:
        ollama_models = await client.list_models()
        return {"success": True, "models": ollama_models}
    except Exception as e:
        return {"success": False, "error": str(e)}

@router.get("/recommendations")
async def get_recommendations():
    return {"success": True, "recommendations": model_router.get_recommendations()}
