"""Chat Routes"""
from fastapi import APIRouter
from atlas import config
from atlas.models.ollama_client import client
from atlas.models.router import router as model_router

router = APIRouter()


def _with_brand_system_message(messages: list) -> list:
    """Prepend the brand system prompt unless the caller already supplied
    their own system message (so a client can override the persona)."""
    if messages and messages[0].get("role") == "system":
        return messages
    return [{"role": "system", "content": config.BRAND_SYSTEM_PROMPT}, *messages]


@router.post("/completion")
async def chat_completion(body: dict):
    messages = _with_brand_system_message(body.get("messages", []))
    user_turns = [m for m in messages if m.get("role") == "user"]
    model = body.get("model") or model_router.recommend_for_task(
        user_turns[0].get("content", "") if user_turns else ""
    )
    try:
        result = await client.chat(model, messages, temperature=body.get("temperature", config.DEFAULT_TEMPERATURE))
        return {
            "success": True,
            "response": result.get("message", {}).get("content", ""),
            "model": model,
            "brand": config.BRAND_NAME,
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

@router.post("/generate")
async def generate(body: dict):
    model = body.get("model") or config.PLANNER_MODEL
    system = body.get("system") or config.BRAND_SYSTEM_PROMPT
    try:
        result = await client.generate(
            model, body.get("prompt", ""), system=system, temperature=body.get("temperature", config.DEFAULT_TEMPERATURE)
        )
        return {"success": True, "response": result.get("response", ""), "model": model, "brand": config.BRAND_NAME}
    except Exception as e:
        return {"success": False, "error": str(e)}
