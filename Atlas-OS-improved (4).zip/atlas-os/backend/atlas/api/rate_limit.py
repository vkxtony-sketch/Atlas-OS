"""Rate Limiting

An in-memory sliding-window limiter keyed by API key (falling back to
client IP if unauthenticated). Deliberately simple: on a single-process,
single-box deployment there's no need for Redis or a distributed limiter.
If you later run multiple worker processes behind a load balancer, move
this state to Redis instead.
"""
import time
from collections import defaultdict
from threading import Lock

from fastapi import Request
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from atlas import config

_WINDOW_SECONDS = 60


class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app):
        super().__init__(app)
        self._hits: dict[str, list] = defaultdict(list)
        self._lock = Lock()

    def _identity(self, request: Request) -> str:
        auth = request.headers.get("authorization", "")
        if auth.startswith("Bearer "):
            return auth.removeprefix("Bearer ").strip()
        client = request.client
        return client.host if client else "unknown"

    async def dispatch(self, request: Request, call_next):
        # Only rate-limit actual API calls, not health checks or static assets.
        if not request.url.path.startswith("/api/"):
            return await call_next(request)

        identity = self._identity(request)
        now = time.monotonic()
        limit = config.RATE_LIMIT_PER_MINUTE

        with self._lock:
            hits = self._hits[identity]
            cutoff = now - _WINDOW_SECONDS
            while hits and hits[0] < cutoff:
                hits.pop(0)

            if len(hits) >= limit:
                retry_after = max(1, int(_WINDOW_SECONDS - (now - hits[0])))
                return JSONResponse(
                    status_code=429,
                    content={
                        "success": False,
                        "error": f"Rate limit exceeded ({limit}/min). Try again shortly.",
                    },
                    headers={"Retry-After": str(retry_after)},
                )

            hits.append(now)

        return await call_next(request)
