"""Performance Agent"""
from typing import Dict, Optional

from atlas.agents.base import BaseAgent, Tool, register_agent
from atlas.core.tools import make_toolset


class PerformanceAgent(BaseAgent):
    model = "mistral"
    temperature = 0.3

    def __init__(self):
        super().__init__(
            name="performance",
            description="Analyzes and optimizes code for speed, memory, and efficiency.",
            capabilities=["profiling", "optimization", "bottleneck_detection"],
        )

    def get_tools(self, workspace_dir: Optional[str]) -> Dict[str, Tool]:
        if not workspace_dir:
            return {}
        fns = make_toolset(workspace_dir)
        return {
            "read_file": Tool(
                "read_file", "Read a file's contents.", {"path": "relative file path"}, fns["read_file"]
            ),
            "run_command": Tool(
                "run_command",
                "Run an allowlisted profiling/benchmark command (e.g. 'python -m cProfile script.py').",
                {"command": "the full command line to run"},
                fns["run_command"],
            ),
            "write_file": Tool(
                "write_file",
                "Save an optimized version of a file.",
                {"path": "relative file path", "content": "full file contents"},
                fns["write_file"],
            ),
        }


register_agent(PerformanceAgent())
