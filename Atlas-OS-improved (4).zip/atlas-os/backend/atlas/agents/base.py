"""Base Agent

Agents in Atlas OS can be pure LLM responders (no tools) or tool-using
agents that run an iterative ReAct-style loop: think, call a tool, observe
the result, and repeat until they produce a final answer. This is what lets
an agent actually *do* things (read/write files, run tests, use git)
instead of just describing what it would do.
"""
from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

from atlas.config import AGENT_MAX_ITERATIONS, DEFAULT_TEMPERATURE
from atlas.models.ollama_client import client
from atlas.utils.logger import logger


@dataclass
class Tool:
    name: str
    description: str
    parameters: Dict[str, str]  # param_name -> human-readable description
    fn: Callable[..., str]

    def schema_line(self) -> str:
        params = ", ".join(f"{k} ({v})" for k, v in self.parameters.items()) or "no arguments"
        return f"- {self.name}({params}): {self.description}"


class BaseAgent(ABC):
    model: str = "llama3.2"
    temperature: float = DEFAULT_TEMPERATURE
    max_iterations: int = AGENT_MAX_ITERATIONS

    def __init__(self, name: str, description: str, capabilities: List[str]):
        self.name = name
        self.description = description
        self.capabilities = capabilities
        self.status = "idle"

    # --- Override points for subclasses -------------------------------

    def get_tools(self, workspace_dir: Optional[str]) -> Dict[str, Tool]:
        """Return tools available to this agent for a given project workspace.

        Default is no tools (pure LLM responder). Tool-using agents override
        this and bind tools to `workspace_dir` via atlas.core.tools.make_toolset.
        """
        return {}

    def system_prompt(self) -> str:
        return (
            f"You are the {self.name} agent inside Atlas OS, a local multi-agent "
            f"task-completion system. {self.description}"
        )

    # --- Public entry point --------------------------------------------

    async def execute(
        self, task: str, context: str = "", workspace_dir: Optional[str] = None
    ) -> Dict[str, Any]:
        self.status = "busy"
        trace: List[Dict[str, Any]] = []
        try:
            tools = self.get_tools(workspace_dir)
            if not tools:
                output = await self._simple_call(task, context)
                return {"success": True, "output": output, "agent": self.name, "trace": trace}

            output = await self._react_loop(task, context, tools, trace)
            return {"success": True, "output": output, "agent": self.name, "trace": trace}
        except Exception as e:
            logger.exception(f"{self.name} agent failed")
            return {"success": False, "error": str(e), "agent": self.name, "trace": trace}
        finally:
            self.status = "idle"

    # --- Internals -------------------------------------------------------

    async def _simple_call(self, task: str, context: str) -> str:
        prompt = task if not context else f"{task}\n\nContext:\n{context}"
        result = await client.generate(
            self.model, prompt, system=self.system_prompt(), temperature=self.temperature
        )
        return result.get("response", "")

    async def _react_loop(
        self, task: str, context: str, tools: Dict[str, Tool], trace: List[Dict[str, Any]]
    ) -> str:
        tool_docs = "\n".join(t.schema_line() for t in tools.values())
        sys_prompt = (
            f"{self.system_prompt()}\n\n"
            f"You can use these tools:\n{tool_docs}\n\n"
            "Respond in EXACTLY this format each turn:\n"
            "Thought: <your reasoning>\n"
            "Action: <tool name>\n"
            "Action Input: <a single-line JSON object of arguments>\n\n"
            "When you are done, respond instead with:\n"
            "Thought: <your reasoning>\n"
            "Final Answer: <the complete result the user asked for>\n\n"
            "Rules: produce exactly one Thought/Action pair OR one Thought/Final Answer "
            "per response. Never invent a tool that isn't listed above. Use write_file to "
            "actually save any code or documents you produce, don't just describe them."
        )

        transcript = f"Task: {task}"
        if context:
            transcript += f"\nContext:\n{context}"

        last_observation = ""
        for i in range(self.max_iterations):
            result = await client.generate(
                self.model, transcript, system=sys_prompt, temperature=self.temperature
            )
            reply = result.get("response", "").strip()
            step_record: Dict[str, Any] = {"step": i + 1, "raw": reply}
            trace.append(step_record)

            final = re.search(r"Final Answer:\s*(.*)", reply, re.DOTALL)
            if final:
                return final.group(1).strip()

            action_match = re.search(r"Action:\s*([\w_]+)", reply)
            input_match = re.search(r"Action Input:\s*(\{.*\})", reply, re.DOTALL)

            if not action_match:
                # Model didn't follow the format at all; treat its reply as the answer
                # rather than looping forever on malformed output.
                return reply

            tool_name = action_match.group(1).strip()
            tool = tools.get(tool_name)
            if not tool:
                observation = f"Error: unknown tool '{tool_name}'. Available: {', '.join(tools)}"
            else:
                args = {}
                if input_match:
                    try:
                        args = json.loads(input_match.group(1))
                    except json.JSONDecodeError:
                        observation = "Error: Action Input was not valid JSON."
                        step_record["tool"] = tool_name
                        step_record["observation"] = observation
                        transcript += f"\n{reply}\nObservation: {observation}\n"
                        last_observation = observation
                        continue
                try:
                    observation = tool.fn(**args)
                except TypeError as e:
                    observation = f"Error: bad arguments for {tool_name}: {e}"
                except Exception as e:
                    observation = f"Error running {tool_name}: {e}"
                observation = str(observation)[:4000]

            step_record["tool"] = tool_name
            step_record["observation"] = observation
            transcript += f"\n{reply}\nObservation: {observation}\n"
            last_observation = observation

        return (
            "Reached the maximum number of steps without a final answer. "
            f"Last observation:\n{last_observation}"
        )

    def get_info(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "description": self.description,
            "capabilities": self.capabilities,
            "status": self.status,
        }


AGENTS_REGISTRY: Dict[str, "BaseAgent"] = {}


def register_agent(agent: BaseAgent):
    AGENTS_REGISTRY[agent.name] = agent


def get_agent(name: str) -> Optional[BaseAgent]:
    return AGENTS_REGISTRY.get(name)


def list_all_agents() -> List[Dict[str, Any]]:
    return [a.get_info() for a in AGENTS_REGISTRY.values()]
