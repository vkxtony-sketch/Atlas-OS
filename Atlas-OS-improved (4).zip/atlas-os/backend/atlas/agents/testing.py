"""Testing Agent"""
from typing import Dict, Optional

from atlas.agents.base import BaseAgent, Tool, register_agent
from atlas.core.tools import make_toolset


class TestingAgent(BaseAgent):
    model = "deepseek-coder-v2"
    temperature = 0.3

    def __init__(self):
        super().__init__(
            name="testing",
            description=(
                "Writes unit/integration tests and runs them (e.g. pytest, npm test) "
                "to verify they actually pass."
            ),
            capabilities=["unit_tests", "integration_tests", "test_plans", "test_execution"],
        )

    def get_tools(self, workspace_dir: Optional[str]) -> Dict[str, Tool]:
        if not workspace_dir:
            return {}
        fns = make_toolset(workspace_dir)
        return {
            "read_file": Tool(
                "read_file", "Read a file's contents.", {"path": "relative file path"}, fns["read_file"]
            ),
            "write_file": Tool(
                "write_file",
                "Create or overwrite a test file.",
                {"path": "relative file path", "content": "full file contents"},
                fns["write_file"],
            ),
            "list_dir": Tool(
                "list_dir", "List files in a directory.", {"path": "relative directory path, default '.'"}, fns["list_dir"]
            ),
            "run_command": Tool(
                "run_command",
                "Run an allowlisted developer command (e.g. 'pytest -q', 'npm test') in the workspace.",
                {"command": "the full command line to run"},
                fns["run_command"],
            ),
        }


register_agent(TestingAgent())
