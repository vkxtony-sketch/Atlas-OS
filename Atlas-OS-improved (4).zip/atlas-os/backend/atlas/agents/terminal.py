"""Terminal Agent"""
from typing import Dict, Optional

from atlas.agents.base import BaseAgent, Tool, register_agent
from atlas.core.tools import ALLOWED_BINARIES, make_toolset


class TerminalAgent(BaseAgent):
    model = "llama3.2"
    temperature = 0.2

    def __init__(self):
        super().__init__(
            name="terminal",
            description=(
                "Runs shell commands scoped to the project workspace, restricted to an "
                "allowlist of developer tools ("
                + ", ".join(sorted(ALLOWED_BINARIES))
                + "). It cannot run sudo, pipes/redirects, or arbitrary binaries."
            ),
            capabilities=["shell_execution", "file_operations"],
        )

    def get_tools(self, workspace_dir: Optional[str]) -> Dict[str, Tool]:
        if not workspace_dir:
            return {}
        fns = make_toolset(workspace_dir)
        return {
            "run_command": Tool(
                "run_command",
                "Run an allowlisted shell command in the project workspace.",
                {"command": "the full command line to run"},
                fns["run_command"],
            ),
            "list_dir": Tool(
                "list_dir", "List files in a directory.", {"path": "relative directory path, default '.'"}, fns["list_dir"]
            ),
            "read_file": Tool(
                "read_file", "Read a file's contents.", {"path": "relative file path"}, fns["read_file"]
            ),
        }


register_agent(TerminalAgent())
