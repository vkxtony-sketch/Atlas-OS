"""Knowledge Agent"""
from typing import Dict, Optional

from atlas.agents.base import BaseAgent, Tool, register_agent
from atlas.knowledge_base.chroma_store import store
from atlas.knowledge_base.indexer import indexer


def _search_kb(query: str, top_k: int = 5) -> str:
    results = store.search(query, int(top_k))
    if not results:
        return "No matching documents found in the knowledge base."
    lines = []
    for r in results:
        snippet = (r.get("content") or "")[:500]
        lines.append(f"[distance={r.get('distance', 1.0):.3f}] {snippet}")
    return "\n---\n".join(lines)


def _index_text(text: str, source: str = "agent") -> str:
    doc_id = indexer.index_text(text, {"source": source})
    return f"Indexed as document {doc_id}"


class KnowledgeAgent(BaseAgent):
    model = "llama3.2"

    def __init__(self):
        super().__init__(
            name="knowledge",
            description="Searches and indexes the project's knowledge base (ChromaDB) to ground answers in real documents.",
            capabilities=["indexing", "querying", "retrieval"],
        )

    def get_tools(self, workspace_dir: Optional[str]) -> Dict[str, Tool]:
        return {
            "search_knowledge_base": Tool(
                "search_knowledge_base",
                "Semantic-search the knowledge base for relevant indexed documents.",
                {"query": "search text", "top_k": "number of results, default 5"},
                _search_kb,
            ),
            "index_text": Tool(
                "index_text",
                "Add a piece of text to the knowledge base for future retrieval.",
                {"text": "the text to index", "source": "a short label for where it came from"},
                _index_text,
            ),
        }


register_agent(KnowledgeAgent())
