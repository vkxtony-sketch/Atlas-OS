"""Security Agent"""
from typing import Dict, Optional

from atlas.agents.base import BaseAgent, Tool, register_agent
from atlas.core.tools import make_toolset


class SecurityAgent(BaseAgent):
    model = "llama3.2"
    temperature = 0.2

    def __init__(self):
        super().__init__(
            name="security",
            description=(
                "Audits code and configuration for security vulnerabilities and bad "
                "practices. Read-only: it never modifies files or runs commands."
            ),
            capabilities=["security_audit", "vulnerability_scan", "best_practices"],
        )

    def get_tools(self, workspace_dir: Optional[str]) -> Dict[str, Tool]:
        if not workspace_dir:
            return {}
        fns = make_toolset(workspace_dir)
        return {
            "read_file": Tool(
                "read_file", "Read a file's contents to audit it.", {"path": "relative file path"}, fns["read_file"]
            ),
            "list_dir": Tool(
                "list_dir",
                "List files in a directory to find things to audit.",
                {"path": "relative directory path, default '.'"},
                fns["list_dir"],
            ),
        }


register_agent(SecurityAgent())
