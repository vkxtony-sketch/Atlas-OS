"""Git Agent"""
from typing import Dict, Optional

from atlas.agents.base import BaseAgent, Tool, register_agent
from atlas.core.tools import make_toolset


class GitAgent(BaseAgent):
    model = "llama3.2"
    temperature = 0.2

    def __init__(self):
        super().__init__(
            name="git",
            description="Manages Git operations like status, commits, branches, and diffs.",
            capabilities=["commit", "branch", "diff", "status", "log"],
        )

    def get_tools(self, workspace_dir: Optional[str]) -> Dict[str, Tool]:
        if not workspace_dir:
            return {}
        fns = make_toolset(workspace_dir)
        return {
            "git_command": Tool(
                "git_command",
                "Run a git subcommand (status, add, commit, branch, checkout, log, diff, "
                "merge, pull, push, fetch, init, remote, stash, tag, show, rev-parse).",
                {"args": "the arguments to git, e.g. 'commit -m \"message\"'"},
                fns["git_command"],
            ),
            "list_dir": Tool(
                "list_dir", "List files in a directory.", {"path": "relative directory path, default '.'"}, fns["list_dir"]
            ),
        }


register_agent(GitAgent())
