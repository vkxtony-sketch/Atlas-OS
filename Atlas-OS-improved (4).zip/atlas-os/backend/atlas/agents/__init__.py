"""Atlas OS Agents

Importing this package registers every specialist agent. Each agent module
calls register_agent(...) as a side effect of being imported, so they must
all be imported here -- otherwise the registry stays empty.
"""
from atlas.agents import (  # noqa: F401
    coding,
    deployment,
    documentation,
    executive,
    git,
    knowledge,
    performance,
    research,
    security,
    terminal,
    testing,
)
