"""Research Agent"""
from typing import Dict, Optional

from atlas.agents.base import BaseAgent, Tool, register_agent
from atlas.agents.knowledge import _search_kb


class ResearchAgent(BaseAgent):
    model = "mistral"

    def __init__(self):
        super().__init__(
            name="research",
            description=(
                "Researches topics and synthesizes findings. Atlas OS is local-first with "
                "no internet access, so this agent grounds its answers in the local "
                "knowledge base rather than live web search; clearly flag anything it "
                "cannot verify locally."
            ),
            capabilities=["research", "summarization"],
        )

    def get_tools(self, workspace_dir: Optional[str]) -> Dict[str, Tool]:
        return {
            "search_knowledge_base": Tool(
                "search_knowledge_base",
                "Semantic-search the local knowledge base for relevant indexed documents.",
                {"query": "search text", "top_k": "number of results, default 5"},
                _search_kb,
            ),
        }


register_agent(ResearchAgent())
