"""Coding Agent"""
import re
from typing import Any, Dict, Optional

from atlas.agents.base import BaseAgent, Tool, register_agent
from atlas.core.tools import make_toolset


class CodingAgent(BaseAgent):
    model = "deepseek-coder-v2"
    temperature = 0.3

    def __init__(self):
        super().__init__(
            name="coding",
            description=(
                "Generates, reviews, debugs, and refactors code in any language, "
                "reading and writing files directly in the project workspace."
            ),
            capabilities=["code_generation", "code_review", "debugging", "refactoring", "file_editing"],
        )

    def get_tools(self, workspace_dir: Optional[str]) -> Dict[str, Tool]:
        if not workspace_dir:
            return {}
        fns = make_toolset(workspace_dir)
        return {
            "read_file": Tool(
                "read_file", "Read a file's contents.", {"path": "relative file path"}, fns["read_file"]
            ),
            "write_file": Tool(
                "write_file",
                "Create or overwrite a file with new content.",
                {"path": "relative file path", "content": "full file contents"},
                fns["write_file"],
            ),
            "list_dir": Tool(
                "list_dir",
                "List files in a directory.",
                {"path": "relative directory path, default '.'"},
                fns["list_dir"],
            ),
        }

    async def execute_debate(
        self, task: str, context: str = "", workspace_dir: Optional[str] = None
    ) -> Dict[str, Any]:
        """Multi-model debate path: several models independently solve the
        task, critique each other's (anonymized) answers, and converge on
        one solution -- see atlas/core/debate.py. Only after they agree
        (or a judge reconciles a final answer) does this method write the
        result to disk, through the normal sandboxed file tools, so the
        workspace never sees half-finished or conflicting drafts from
        individual models mid-debate.
        """
        from atlas.core.debate import debate_engine  # local import avoids a cycle at module load

        self.status = "busy"
        try:
            debate_result = await debate_engine.run(task, context)
            final_code = debate_result.get("final_code", "")

            if not final_code:
                return {
                    "success": False,
                    "error": debate_result.get("error", "Debate produced no usable solution."),
                    "agent": self.name,
                    "debate": debate_result,
                }

            if workspace_dir:
                write_result = await self._save_result(task, final_code, workspace_dir)
                final_code_note = write_result
            else:
                final_code_note = final_code

            return {
                "success": True,
                "output": final_code_note,
                "agent": self.name,
                "debate": {
                    "converged": debate_result.get("converged"),
                    "agreement_score": debate_result.get("agreement_score"),
                    "rounds": debate_result.get("rounds"),
                    "participants": debate_result.get("participants"),
                },
            }
        except Exception as e:
            return {"success": False, "error": str(e), "agent": self.name}
        finally:
            self.status = "idle"

    async def _save_result(self, task: str, final_code: str, workspace_dir: str) -> str:
        """Ask this agent (with real file tools) to place the already-agreed
        final code into the right file(s), rather than re-deciding the logic.
        Falls back to a single best-guess filename if the model's tool loop
        doesn't cooperate."""
        instruction = (
            "The team has already agreed on the following finished solution for this task:\n\n"
            f"Task: {task}\n\n"
            f"```\n{final_code}\n```\n\n"
            "Save this exact code into the appropriately named file(s) in the project "
            "using write_file. Do not change the logic -- just place it correctly. If it's "
            "clearly one file, use one write_file call."
        )
        result = await self.execute(instruction, "", workspace_dir=workspace_dir)
        if result.get("success"):
            return result.get("output", final_code)
        return final_code


register_agent(CodingAgent())
