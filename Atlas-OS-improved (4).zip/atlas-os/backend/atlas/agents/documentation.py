"""Documentation Agent"""
from typing import Dict, Optional

from atlas.agents.base import BaseAgent, Tool, register_agent
from atlas.core.tools import make_toolset


class DocumentationAgent(BaseAgent):
    model = "llama3.2"

    def __init__(self):
        super().__init__(
            name="documentation",
            description="Writes READMEs, API docs, and inline comments, and saves them to the project.",
            capabilities=["readme_generation", "api_docs", "inline_comments"],
        )

    def get_tools(self, workspace_dir: Optional[str]) -> Dict[str, Tool]:
        if not workspace_dir:
            return {}
        fns = make_toolset(workspace_dir)
        return {
            "read_file": Tool(
                "read_file", "Read a file's contents.", {"path": "relative file path"}, fns["read_file"]
            ),
            "write_file": Tool(
                "write_file",
                "Create or overwrite a documentation file.",
                {"path": "relative file path", "content": "full file contents"},
                fns["write_file"],
            ),
            "list_dir": Tool(
                "list_dir", "List files in a directory.", {"path": "relative directory path, default '.'"}, fns["list_dir"]
            ),
        }


register_agent(DocumentationAgent())
