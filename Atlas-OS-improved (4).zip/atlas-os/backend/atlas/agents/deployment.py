"""Deployment Agent"""
from typing import Dict, Optional

from atlas.agents.base import BaseAgent, Tool, register_agent
from atlas.core.tools import make_toolset


class DeploymentAgent(BaseAgent):
    model = "llama3.2"
    temperature = 0.2

    def __init__(self):
        super().__init__(
            name="deployment",
            description="Handles build and deployment tasks (e.g. running build/package scripts).",
            capabilities=["build", "environment_setup"],
        )

    def get_tools(self, workspace_dir: Optional[str]) -> Dict[str, Tool]:
        if not workspace_dir:
            return {}
        fns = make_toolset(workspace_dir)
        return {
            "run_command": Tool(
                "run_command",
                "Run an allowlisted build/deploy command in the project workspace.",
                {"command": "the full command line to run"},
                fns["run_command"],
            ),
            "read_file": Tool(
                "read_file", "Read a file's contents.", {"path": "relative file path"}, fns["read_file"]
            ),
            "list_dir": Tool(
                "list_dir", "List files in a directory.", {"path": "relative directory path, default '.'"}, fns["list_dir"]
            ),
        }


register_agent(DeploymentAgent())
