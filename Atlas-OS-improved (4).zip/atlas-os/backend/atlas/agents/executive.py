"""Executive Agent"""
from atlas.agents.base import BaseAgent, register_agent


class ExecutiveAgent(BaseAgent):
    model = "llama3.2"

    def __init__(self):
        super().__init__(
            name="executive",
            description=(
                "General-purpose fallback agent used when a goal doesn't clearly match "
                "one of the specialist agents (coding, testing, security, documentation, "
                "research, knowledge, performance, git, deployment, terminal)."
            ),
            capabilities=["planning", "general_reasoning"],
        )


register_agent(ExecutiveAgent())
