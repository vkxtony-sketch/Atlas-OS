"""Document Indexer"""
from typing import Dict, Any
from atlas.knowledge_base.chroma_store import store
import uuid

class DocumentIndexer:
    def index_text(self, text: str, metadata: Dict[str, Any] = None) -> str:
        doc_id = str(uuid.uuid4())
        store.add_document(doc_id, text, metadata or {})
        return doc_id

    def index_file(self, filepath: str) -> str:
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()
            return self.index_text(content, {"file_name": filepath})
        except Exception as e:
            return str(e)

indexer = DocumentIndexer()
