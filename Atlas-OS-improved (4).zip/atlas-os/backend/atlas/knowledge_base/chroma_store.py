"""ChromaDB Vector Store"""
from typing import List, Dict, Any
from atlas.config import CHROMA_PATH

try:
    import chromadb
    CHROMA_AVAILABLE = True
except Exception:
    # Broad except on purpose: chromadb's import chain can fail for reasons
    # other than a missing package (e.g. a numpy version mismatch). Either
    # way, Atlas OS should still boot with the knowledge base disabled
    # rather than crash the whole API.
    CHROMA_AVAILABLE = False

class ChromaStore:
    def __init__(self):
        self.client = None
        self.collection = None
        if CHROMA_AVAILABLE:
            try:
                self.client = chromadb.PersistentClient(path=CHROMA_PATH)
                self.collection = self.client.get_or_create_collection("atlas_kb")
            except Exception:
                pass

    def add_document(self, doc_id: str, content: str, metadata: Dict[str, Any] = None) -> bool:
        if not self.collection:
            return False
        try:
            self.collection.add(ids=[doc_id], documents=[content], metadatas=[metadata or {}])
            return True
        except Exception:
            return False

    def search(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        if not self.collection:
            return []
        try:
            results = self.collection.query(query_texts=[query], n_results=top_k)
            docs = results.get("documents", [[]])[0]
            distances = results.get("distances", [[]])[0]
            metadatas = results.get("metadatas", [[]])[0]
            output = []
            for i, doc in enumerate(docs):
                output.append({"content": doc, "distance": distances[i] if i < len(distances) else 1.0, "metadata": metadatas[i] if i < len(metadatas) else {}})
            return output
        except Exception:
            return []

    def get_stats(self) -> Dict[str, Any]:
        if not self.collection:
            return {"count": 0, "status": "unavailable"}
        try:
            count = self.collection.count()
            return {"count": count, "status": "ready"}
        except Exception:
            return {"count": 0, "status": "error"}

store = ChromaStore()
