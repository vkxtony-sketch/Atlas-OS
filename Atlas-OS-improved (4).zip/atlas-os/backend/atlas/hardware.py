"""Hardware Detection"""
import psutil
import cpuinfo
import platform
from typing import Dict, Any

try:
    import GPUtil
    GPU_AVAILABLE = True
except ImportError:
    GPU_AVAILABLE = False

class HardwareDetector:
    def get_profile(self) -> Dict[str, Any]:
        cpu = cpuinfo.get_cpu_info()
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage("/")

        gpu_devices = []
        total_vram = 0
        if GPU_AVAILABLE:
            try:
                gpus = GPUtil.getGPUs()
                for gpu in gpus:
                    gpu_devices.append({
                        "index": gpu.id,
                        "name": gpu.name,
                        "total_memory_mb": gpu.memoryTotal,
                        "free_memory_mb": gpu.memoryFree,
                        "used_memory_mb": gpu.memoryUsed,
                        "utilization_percent": gpu.load * 100,
                    })
                    total_vram += gpu.memoryTotal
            except Exception:
                pass

        total_ram_mb = ram.total // (1024 * 1024)

        profile = {
            "cpu": {
                "name": cpu.get("brand_raw", "Unknown"),
                "cores_physical": psutil.cpu_count(logical=False) or 1,
                "cores_logical": psutil.cpu_count(logical=True) or 1,
                "frequency_mhz": cpu.get("hz_advertised_friendly", "Unknown"),
                "architecture": platform.machine(),
            },
            "ram": {
                "total_mb": total_ram_mb,
                "available_mb": ram.available // (1024 * 1024),
                "used_mb": ram.used // (1024 * 1024),
                "percent_used": ram.percent,
            },
            "gpu": {
                "count": len(gpu_devices),
                "has_gpu": len(gpu_devices) > 0,
                "total_vram_mb": total_vram,
                "devices": gpu_devices,
            },
            "storage": {
                "total_gb": round(disk.total / (1024**3), 2),
                "free_gb": round(disk.free / (1024**3), 2),
            },
            "os": {
                "name": platform.system(),
                "version": platform.version(),
                "architecture": platform.architecture()[0],
            },
            "capabilities": {
                "can_run_large_models": total_ram_mb > 32000 or total_vram > 24000,
                "can_run_medium_models": total_ram_mb > 16000 or total_vram > 8000,
                "can_run_small_models": total_ram_mb > 4000,
                "recommended_concurrency": min(max(total_ram_mb // 8000, 1), 8),
            },
        }
        return profile

    def get_resources(self) -> Dict[str, Any]:
        ram = psutil.virtual_memory()
        return {
            "cpu_percent": psutil.cpu_percent(interval=0.5),
            "ram_used_mb": ram.used // (1024 * 1024),
            "ram_available_mb": ram.available // (1024 * 1024),
        }

detector = HardwareDetector()
