"""Review / Consensus Engine

Implements the "Cross Review -> Security Review -> Performance Review ->
Architecture Review -> Revision Loop" stages from the Atlas OS design: once
agents produce output, independent reviewer passes critique it in parallel
and classify issues by severity (critical / major / minor / suggestion).
Critical and major issues block completion and trigger a revision pass;
minor issues and suggestions are recorded but don't hold up delivery.

Reviewers run concurrently (not one after another) since they're
independent of each other — this is where a meaningful chunk of the "fast"
in "fast and thorough" comes from.
"""
from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass
from typing import Dict, List

from atlas.config import REVIEW_MODEL
from atlas.models.ollama_client import client
from atlas.utils.logger import logger

SEVERITIES = ("critical", "major", "minor", "suggestion")

REVIEWERS: Dict[str, str] = {
    "security": "Look for security vulnerabilities: injection, unsafe input handling, secret leakage, missing auth/authorization checks, unsafe deserialization.",
    "performance": "Look for performance problems: obvious inefficiencies, unnecessary loops or allocations, unbounded recursion, blocking calls where async is warranted.",
    "architecture": "Look for structural problems: poor separation of concerns, missing error handling, inconsistent interfaces, or the plan not actually satisfying the original goal.",
}


@dataclass
class Issue:
    severity: str
    summary: str
    reviewer: str

    def to_dict(self) -> Dict[str, str]:
        return {"severity": self.severity, "summary": self.summary, "reviewer": self.reviewer}


async def run_reviewer(reviewer_name: str, output: str, model: str = REVIEW_MODEL) -> List[Issue]:
    focus = REVIEWERS.get(reviewer_name, "Look for general correctness issues.")
    system = (
        f"You are the {reviewer_name} reviewer in Atlas OS. {focus}\n"
        "Respond with ONLY a JSON array, no prose, in this exact shape:\n"
        '[{"severity": "critical|major|minor|suggestion", "summary": "short specific description"}]\n'
        "Return [] if you find nothing worth flagging. Be specific, not generic."
    )
    try:
        result = await client.generate(model, output[:6000], system=system, temperature=0.1)
        raw = result.get("response", "")
    except Exception as e:
        logger.error(f"{reviewer_name} reviewer call failed: {e}")
        return []

    match = re.search(r"\[.*\]", raw, re.DOTALL)
    if not match:
        return []
    try:
        items = json.loads(match.group(0))
    except json.JSONDecodeError:
        return []
    if not isinstance(items, list):
        return []

    issues: List[Issue] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        severity = item.get("severity", "minor")
        if severity not in SEVERITIES:
            severity = "minor"
        summary = str(item.get("summary", "")).strip()
        if summary:
            issues.append(Issue(severity=severity, summary=summary, reviewer=reviewer_name))
    return issues


async def review_all(output: str, reviewer_names: List[str] | None = None) -> List[Issue]:
    """Run all reviewer passes concurrently and merge their findings."""
    if not output or not output.strip():
        return []
    reviewer_names = reviewer_names or list(REVIEWERS.keys())
    results = await asyncio.gather(*(run_reviewer(name, output) for name in reviewer_names))
    issues: List[Issue] = []
    for r in results:
        issues.extend(r)
    return issues


def blocking_issues(issues: List[Issue]) -> List[Issue]:
    return [i for i in issues if i.severity in ("critical", "major")]


def format_feedback(issues: List[Issue]) -> str:
    return "\n".join(f"[{i.severity.upper()}] ({i.reviewer}) {i.summary}" for i in issues)
