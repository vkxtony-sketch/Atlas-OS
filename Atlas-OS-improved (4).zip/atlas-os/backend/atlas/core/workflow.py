"""Workflow Orchestrator

Executes a planned goal in phases, mirroring the Atlas OS design doc:

0. If the goal looks under-specified, pause and ask the user clarifying
   questions instead of guessing (see atlas/core/clarify.py). Skipped if
   the caller already supplied `clarifications`.
1. Independent plan steps run concurrently in dependency "levels" (steps
   with no unmet dependencies run together, up to MAX_CONCURRENCY at once)
   instead of one at a time. Coding steps go through the multi-model debate
   engine instead of a single model call when ATLAS_DEBATE_ENABLED=true --
   several local models independently solve the task, critique each
   other's anonymized answers, and converge on one solution before it's
   written to disk.
2. Once all steps finish, security/performance/architecture reviewers run
   concurrently against the combined output and classify issues by
   severity.
3. Critical/major issues trigger a revision pass on the relevant agent(s)
   (bounded by MAX_REVISION_ROUNDS); minor issues and suggestions are
   attached to the final result instead of blocking it.
4. If the result still isn't good enough after that (quality score below
   ATLAS_QUALITY_THRESHOLD, or blocking issues remain), the whole
   plan -> build -> review -> revise pass repeats with the accumulated
   feedback folded into the goal, up to ATLAS_MAX_PROJECT_ITERATIONS times,
   instead of quitting after a single attempt.
"""
from __future__ import annotations

import asyncio
from typing import Any, AsyncGenerator, Dict, List, Optional

from atlas.agents.base import get_agent
from atlas.config import (
    CLARIFY_ENABLED,
    CLARIFY_MAX_QUESTIONS,
    DEBATE_ENABLED,
    MAX_CONCURRENCY,
    MAX_PROJECT_ITERATIONS,
    MAX_REVISION_ROUNDS,
    QUALITY_THRESHOLD,
)
from atlas.core.clarify import needs_clarification
from atlas.core.consensus import consensus
from atlas.core.memory import memory
from atlas.core.planner import planner
from atlas.core.quality import scorer
from atlas.core.review import blocking_issues, format_feedback, review_all


def _plan_levels(plan: List[Dict[str, Any]]) -> List[List[int]]:
    """Group step indices into levels that can run concurrently.

    Level 0 = steps with no dependencies. Level 1 = steps whose
    dependencies are all in level 0. And so on. Guards against bad/cyclic
    depends_on data by dumping any stuck steps into their own level rather
    than looping forever.
    """
    n = len(plan)
    resolved: set = set()
    remaining = set(range(n))
    levels: List[List[int]] = []

    while remaining:
        ready = [i for i in remaining if all(d in resolved for d in plan[i].get("depends_on", []))]
        if not ready:
            ready = sorted(remaining)  # cycle guard
        levels.append(sorted(ready))
        resolved.update(ready)
        remaining -= set(ready)

    return levels


class WorkflowOrchestrator:
    async def execute_goal(
        self,
        goal: str,
        workspace_dir: Optional[str] = None,
        clarifications: Optional[Dict[str, str]] = None,
        project_id: Optional[str] = None,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        # --- Phase 0: clarify, if needed and not already answered ---------
        if clarifications:
            answers = "\n".join(f"Q: {q}\nA: {a}" for q, a in clarifications.items())
            goal = f"{goal}\n\nClarifications the user already provided:\n{answers}"
        elif CLARIFY_ENABLED:
            yield {"type": "clarify_check", "message": "Checking whether the goal needs clarification..."}
            questions = await needs_clarification(goal, CLARIFY_MAX_QUESTIONS)
            if questions:
                yield {
                    "type": "clarification_needed",
                    "questions": questions,
                    "message": "Need a bit more information before starting.",
                }
                return

        memory_context = await memory.build_context(project_id)
        if memory_context:
            yield {"type": "memory_loaded", "message": "Loaded preferences and project history."}
            goal = f"{goal}\n\n{memory_context}"

        extra_feedback = ""
        final: Dict[str, Any] = {}
        blocking: List[Any] = []
        all_issues: List[Any] = []
        revision_round = 0
        iteration = 0

        while True:
            iteration += 1
            iteration_goal = goal if not extra_feedback else f"{goal}\n\nAddress this unresolved feedback from the previous attempt:\n{extra_feedback}"

            yield {
                "type": "iteration_start",
                "iteration": iteration,
                "max_iterations": MAX_PROJECT_ITERATIONS,
                "message": f"Starting attempt {iteration}/{MAX_PROJECT_ITERATIONS}...",
            }

            yield {"type": "planning", "message": "Analyzing goal and creating plan..."}
            plan = await planner.plan(iteration_goal)
            yield {"type": "plan", "plan": plan, "iteration": iteration}

            results: Dict[int, Dict[str, Any]] = {}
            levels = _plan_levels(plan)
            semaphore = asyncio.Semaphore(MAX_CONCURRENCY)

            for level in levels:
                for idx in level:
                    yield {
                        "type": "task_start",
                        "stage": idx + 1,
                        "total": len(plan),
                        "agent": plan[idx]["agent"],
                        "message": f"Running {plan[idx]['agent']}...",
                    }

                async def run_step(idx: int):
                    step = plan[idx]
                    agent = get_agent(step["agent"])
                    if not agent:
                        return idx, {"success": False, "error": f"Agent '{step['agent']}' not found"}
                    dep_context = "\n\n".join(
                        f"Output from step {d + 1} ({plan[d]['agent']}):\n{(results[d].get('output') or '')[:1500]}"
                        for d in step.get("depends_on", [])
                        if d in results and results[d].get("success")
                    )
                    use_debate = DEBATE_ENABLED and step["agent"] == "coding" and hasattr(agent, "execute_debate")
                    async with semaphore:
                        if use_debate:
                            result = await agent.execute_debate(step["task"], dep_context, workspace_dir=workspace_dir)
                        else:
                            result = await agent.execute(step["task"], dep_context, workspace_dir=workspace_dir)
                        if not result.get("success"):
                            result = await agent.execute(step["task"], dep_context, workspace_dir=workspace_dir)
                    return idx, result

                for coro in asyncio.as_completed([run_step(i) for i in level]):
                    idx, result = await coro
                    results[idx] = result
                    preview = (result.get("output") or result.get("error") or "")[:400]
                    event = {
                        "type": "task_complete",
                        "stage": idx + 1,
                        "agent": plan[idx]["agent"],
                        "success": result.get("success", False),
                        "output_preview": preview,
                    }
                    if "debate" in result:
                        event["debate"] = result["debate"]
                    yield event
                    if not result.get("success"):
                        yield {"type": "error", "message": result.get("error", "step failed")}

            yield {"type": "consensus", "message": "Aggregating results..."}
            ordered_results = [results[i] for i in range(len(plan)) if i in results]
            final = consensus.aggregate(ordered_results)

            yield {"type": "review", "message": "Running security/performance/architecture review..."}
            all_issues = await review_all(final.get("output", ""))
            blocking = blocking_issues(all_issues)

            revision_round = 0
            coding_indices = [i for i in results if plan[i]["agent"] in ("coding", "documentation")]
            while blocking and revision_round < MAX_REVISION_ROUNDS and coding_indices:
                revision_round += 1
                yield {
                    "type": "revision",
                    "round": revision_round,
                    "issues": [i.to_dict() for i in blocking],
                    "message": f"Revising to address {len(blocking)} critical/major issue(s)...",
                }
                feedback = format_feedback(blocking)
                for idx in coding_indices:
                    step = plan[idx]
                    agent = get_agent(step["agent"])
                    revise_task = f"Revise your previous work to fix these review findings:\n{feedback}"
                    result = await agent.execute(
                        revise_task, results[idx].get("output", ""), workspace_dir=workspace_dir
                    )
                    if result.get("success"):
                        results[idx] = result

                ordered_results = [results[i] for i in range(len(plan)) if i in results]
                final = consensus.aggregate(ordered_results)
                all_issues = await review_all(final.get("output", ""))
                blocking = blocking_issues(all_issues)

            quality = {"score": 0, "checks": []}
            if final.get("output"):
                quality = scorer.score_code(final["output"])
            final["quality_score"] = quality["score"]
            final["quality_checks"] = quality["checks"]

            yield {
                "type": "iteration_complete",
                "iteration": iteration,
                "quality_score": quality["score"],
                "unresolved_issues": len(blocking),
            }

            good_enough = quality["score"] >= QUALITY_THRESHOLD and not blocking
            if good_enough or iteration >= MAX_PROJECT_ITERATIONS:
                break

            extra_feedback = format_feedback(blocking) if blocking else f"Quality score was only {quality['score']}/100 ({', '.join(quality['checks']) or 'no strengths detected'}); improve it."
            yield {
                "type": "iteration_retry",
                "message": f"Not done yet (score {quality['score']}/100, {len(blocking)} blocking issue(s)) -- trying again.",
            }

        if project_id:
            await memory.record_event(
                project_id,
                "goal",
                f"Completed: {goal[:200]} (quality {final.get('quality_score', 0)}/100, "
                f"{iteration} iteration(s), {len(blocking)} unresolved issue(s))",
            )
            for issue in all_issues:
                if issue.reviewer == "architecture":
                    await memory.record_event(project_id, "architecture_note", issue.summary)

        yield {
            "type": "complete",
            "output": final.get("output", ""),
            "quality_score": final.get("quality_score", 0),
            "success_count": final.get("success_count", 0),
            "agent_count": final.get("agent_count", 0),
            "iterations": iteration,
            "revision_rounds": revision_round,
            "unresolved_issues": [i.to_dict() for i in blocking],
            "all_issues": [i.to_dict() for i in all_issues],
        }


orchestrator = WorkflowOrchestrator()
