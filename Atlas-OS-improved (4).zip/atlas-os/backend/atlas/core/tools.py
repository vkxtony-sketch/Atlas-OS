"""Sandboxed tools available to agents.

All filesystem and command tools are confined to a single project's
workspace directory (path confinement) and shell commands are restricted to
an allowlist of developer binaries, run without a shell (no `shell=True`,
no string interpolation) and under a timeout.

This is best-effort process-level sandboxing, not a full OS-level sandbox.
For executing genuinely untrusted code, run Atlas OS (or at least the
terminal/deployment agents) inside a container or VM.
"""
from __future__ import annotations

import os
import shlex
import subprocess
from pathlib import Path
from typing import Callable, Dict

ALLOWED_BINARIES = {
    "git", "python", "python3", "pip", "pip3", "pytest", "node", "npm", "npx",
    "yarn", "pnpm", "ls", "cat", "echo", "mkdir", "go", "cargo", "rustc",
    "javac", "java", "tsc", "black", "ruff", "flake8", "mypy", "grep", "find",
    "wc", "head", "tail", "make",
}

# Substrings that are never allowed anywhere in a command, even if the
# leading binary is on the allowlist (defends against `python -c "os.system(...)"`
# style escapes and shell metacharacter abuse in argv).
BLOCKED_SUBSTRINGS = ("&&", "||", ";", "|", "`", "$(", ">", "<", "sudo", "rm -rf")

DEFAULT_TIMEOUT_SECONDS = 60

GIT_SUBCOMMAND_ALLOWLIST = {
    "status", "add", "commit", "branch", "checkout", "log", "diff", "merge",
    "pull", "push", "fetch", "init", "remote", "stash", "tag", "show", "rev-parse",
}


class SandboxError(Exception):
    pass


def _resolve(workspace_dir: str, relative_path: str) -> Path:
    """Resolve a path relative to the workspace and refuse to leave it."""
    base = Path(workspace_dir).resolve()
    target = (base / relative_path).resolve()
    if target != base and base not in target.parents:
        raise SandboxError(f"Path '{relative_path}' escapes the project workspace.")
    return target


def make_toolset(workspace_dir: str) -> Dict[str, Callable[..., str]]:
    """Build filesystem/shell/git tool callables bound to one workspace."""
    Path(workspace_dir).mkdir(parents=True, exist_ok=True)

    def read_file(path: str) -> str:
        try:
            p = _resolve(workspace_dir, path)
        except SandboxError as e:
            return f"Error: {e}"
        if not p.exists():
            return f"Error: {path} does not exist."
        if not p.is_file():
            return f"Error: {path} is not a file."
        return p.read_text(encoding="utf-8", errors="replace")[:20000]

    def write_file(path: str, content: str = "") -> str:
        try:
            p = _resolve(workspace_dir, path)
        except SandboxError as e:
            return f"Error: {e}"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        return f"Wrote {len(content)} bytes to {path}"

    def list_dir(path: str = ".") -> str:
        try:
            p = _resolve(workspace_dir, path)
        except SandboxError as e:
            return f"Error: {e}"
        if not p.exists():
            return f"Error: {path} does not exist."
        entries = sorted(os.listdir(p))
        return "\n".join(entries) if entries else "(empty directory)"

    def run_command(command: str) -> str:
        if any(bad in command for bad in BLOCKED_SUBSTRINGS):
            return "Error: command contains a disallowed character or keyword."
        try:
            parts = shlex.split(command)
        except ValueError as e:
            return f"Error parsing command: {e}"
        if not parts:
            return "Error: empty command"
        binary = os.path.basename(parts[0])
        if binary not in ALLOWED_BINARIES:
            allowed = ", ".join(sorted(ALLOWED_BINARIES))
            return f"Error: '{binary}' is not an allowlisted tool. Allowed: {allowed}"
        try:
            result = subprocess.run(
                parts,
                cwd=workspace_dir,
                capture_output=True,
                text=True,
                timeout=DEFAULT_TIMEOUT_SECONDS,
            )
            output = result.stdout if result.returncode == 0 else (result.stdout + result.stderr)
            return output[:8000] or f"(command exited {result.returncode} with no output)"
        except subprocess.TimeoutExpired:
            return f"Error: command timed out after {DEFAULT_TIMEOUT_SECONDS}s"
        except Exception as e:
            return f"Error executing command: {e}"

    def git_command(args: str) -> str:
        try:
            parts = shlex.split(args)
        except ValueError as e:
            return f"Error parsing git args: {e}"
        if not parts or parts[0] not in GIT_SUBCOMMAND_ALLOWLIST:
            allowed = ", ".join(sorted(GIT_SUBCOMMAND_ALLOWLIST))
            return f"Error: git subcommand must be one of: {allowed}"
        try:
            result = subprocess.run(
                ["git", *parts],
                cwd=workspace_dir,
                capture_output=True,
                text=True,
                timeout=30,
            )
            output = result.stdout if result.returncode == 0 else (result.stdout + result.stderr)
            return output[:8000] or f"(git exited {result.returncode} with no output)"
        except subprocess.TimeoutExpired:
            return "Error: git command timed out"
        except Exception as e:
            return f"Error running git: {e}"

    return {
        "read_file": read_file,
        "write_file": write_file,
        "list_dir": list_dir,
        "run_command": run_command,
        "git_command": git_command,
    }
