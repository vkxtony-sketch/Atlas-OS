"""Multi-Model Debate Engine

The core idea: don't trust a single local model's first answer on a coding
task. Instead:

1. Every model in `config.DEBATE_MODELS` independently answers the exact
   same prompt (no peeking at each other yet).
2. Each model is then shown the other candidates -- anonymized as
   "Solution A/B/C" so it can't just defer to a model it recognizes as
   "smarter" -- and asked to critique them and produce its own best
   revision, incorporating whatever it thinks is actually good.
3. After each round, candidates are compared pairwise (difflib). If they've
   converged (similar enough), the debate stops early. Otherwise it repeats
   up to `config.DEBATE_MAX_ROUNDS`.
4. If the models never fully converge, a judge pass (REVIEW_MODEL) picks
   and lightly reconciles the strongest candidate rather than shipping
   something no model actually endorsed.

Only `result["final_code"]` is meant to be shown to the user by default;
`result["transcript"]` holds the round-by-round detail for anyone who wants
to inspect how the models got there.

Models are queried ONE AT A TIME, not concurrently -- see the note in
config.py about why, for CPU-only hardware.
"""
from __future__ import annotations

import difflib
import itertools
import re
from typing import Any, Dict, List

from atlas import config
from atlas.core.quality import scorer
from atlas.models.ollama_client import client
from atlas.utils.logger import logger

_LABELS = "ABCDEFGH"


def _extract_code(raw: str) -> str:
    """Pull the main fenced code block out of a model's reply, falling back
    to the raw reply if it didn't use one."""
    blocks = re.findall(r"```(?:\w+)?\n(.*?)```", raw, re.DOTALL)
    if blocks:
        return max(blocks, key=len).strip()
    return raw.strip()


def _pairwise_agreement(candidates: List[str]) -> float:
    """Lowest pairwise similarity ratio across all candidates -- a cheap,
    dependency-free stand-in for 'have these converged on the same answer'.
    Returns 1.0 for a single candidate (trivially agrees with itself)."""
    if len(candidates) < 2:
        return 1.0
    ratios = [
        difflib.SequenceMatcher(None, a, b).ratio()
        for a, b in itertools.combinations(candidates, 2)
    ]
    return min(ratios)


class DebateEngine:
    async def _propose(self, model: str, task: str, context: str) -> str:
        system = (
            "You are a careful senior engineer. Solve the coding task completely and "
            "correctly. Respond with a short explanation (2-3 sentences max) followed by "
            "ONE fenced code block containing the complete, runnable solution."
        )
        prompt = task if not context else f"{task}\n\nContext:\n{context}"
        try:
            result = await client.generate(model, prompt, system=system, temperature=0.4)
            return _extract_code(result.get("response", ""))
        except Exception as e:
            logger.error(f"Debate proposal from {model} failed: {e}")
            return ""

    async def _critique_and_revise(
        self, model: str, task: str, context: str, candidates: Dict[str, str], own_label: str
    ) -> str:
        others = "\n\n".join(
            f"Solution {label}:\n```\n{code}\n```"
            for label, code in candidates.items()
        )
        system = (
            "You are a careful senior engineer participating in a code review roundtable. "
            "You will see several candidate solutions to the same task from different "
            "approaches (not labeled by author). Critique them honestly, then write your own "
            "final solution that fixes their weaknesses and keeps their strengths. If one "
            "candidate is already correct and complete, it's fine to largely agree with it. "
            "Respond with a short critique (2-4 sentences) followed by ONE fenced code block "
            "with your complete final solution."
        )
        prompt = (
            f"Original task:\n{task}\n\n"
            + (f"Context:\n{context}\n\n" if context else "")
            + f"Candidate solutions from this round:\n\n{others}\n\n"
            "Write your critique and final solution now."
        )
        try:
            result = await client.generate(model, prompt, system=system, temperature=0.3)
            return _extract_code(result.get("response", ""))
        except Exception as e:
            logger.error(f"Debate revision from {model} failed: {e}")
            return candidates.get(own_label, "")

    async def _judge(self, task: str, candidates: Dict[str, str]) -> str:
        options = "\n\n".join(f"Solution {label}:\n```\n{code}\n```" for label, code in candidates.items())
        system = (
            "You are the tie-breaking judge. Several engineers could not fully converge on a "
            "single solution. Pick the strongest candidate and lightly reconcile it with any "
            "good ideas from the others, producing ONE final, complete, correct solution. "
            "Respond with ONLY a single fenced code block, no prose."
        )
        prompt = f"Task:\n{task}\n\nCandidates:\n\n{options}"
        try:
            result = await client.generate(config.REVIEW_MODEL, prompt, system=system, temperature=0.1)
            return _extract_code(result.get("response", ""))
        except Exception as e:
            logger.error(f"Debate judge call failed: {e}")
            return max(candidates.values(), key=lambda c: scorer.score_code(c)["score"])

    async def run(self, task: str, context: str = "") -> Dict[str, Any]:
        models = config.DEBATE_MODELS or ["llama3.2"]
        transcript: List[Dict[str, Any]] = []

        # Round 0: independent proposals, no peeking.
        candidates: Dict[str, str] = {}
        for label, model in zip(_LABELS, models):
            code = await self._propose(model, task, context)
            if code:
                candidates[label] = code
        model_by_label = dict(zip(_LABELS, models))

        if not candidates:
            return {
                "final_code": "",
                "converged": False,
                "rounds": 0,
                "participants": models,
                "transcript": transcript,
                "error": "All models failed to produce a proposal.",
            }

        agreement = _pairwise_agreement(list(candidates.values()))
        transcript.append({"round": 0, "phase": "propose", "agreement": round(agreement, 3), "candidates": len(candidates)})

        round_num = 0
        while agreement < config.DEBATE_AGREEMENT_THRESHOLD and round_num < config.DEBATE_MAX_ROUNDS and len(candidates) > 1:
            round_num += 1
            new_candidates: Dict[str, str] = {}
            for label in list(candidates.keys()):
                model = model_by_label[label]
                revised = await self._critique_and_revise(model, task, context, candidates, label)
                new_candidates[label] = revised or candidates[label]
            candidates = new_candidates
            agreement = _pairwise_agreement(list(candidates.values()))
            transcript.append({"round": round_num, "phase": "critique_revise", "agreement": round(agreement, 3)})

        converged = agreement >= config.DEBATE_AGREEMENT_THRESHOLD

        if converged:
            # All roughly agree -- ship the highest-quality-scoring one of the near-identical set.
            final_code = max(candidates.values(), key=lambda c: scorer.score_code(c)["score"])
        else:
            final_code = await self._judge(task, candidates)
            transcript.append({"phase": "judge", "note": "Models did not fully converge; judge reconciled a final answer."})

        return {
            "final_code": final_code,
            "converged": converged,
            "agreement_score": round(agreement, 3),
            "rounds": round_num,
            "participants": models,
            "transcript": transcript,
        }


debate_engine = DebateEngine()
