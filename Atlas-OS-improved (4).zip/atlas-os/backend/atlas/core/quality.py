"""Quality Scoring

Heuristic scoring, but honest about it: where we can actually verify
something (e.g. Python syntax validity via ast.parse) we do, rather than
just checking for the presence of substrings like "def " or "# ".
"""
from __future__ import annotations

import ast
import re
from typing import Any, Dict, List


class QualityScorer:
    def score_code(self, content: str) -> Dict[str, Any]:
        if not content or not content.strip():
            return {"score": 0, "checks": ["No content produced"]}

        score = 20
        checks: List[str] = []

        if len(content) > 100:
            score += 10
            checks.append("Substantial content")

        code_blocks = re.findall(r"```(?:\w*)\n(.*?)```", content, re.DOTALL) or [content]
        looks_pythonic = any(("def " in b or "class " in b or "import " in b) for b in code_blocks)
        if looks_pythonic:
            syntax_ok = True
            for block in code_blocks:
                if "def " not in block and "class " not in block and "import " not in block:
                    continue
                try:
                    ast.parse(block)
                except SyntaxError:
                    syntax_ok = False
                    break
            if syntax_ok:
                score += 25
                checks.append("Python syntax is valid")
            else:
                score -= 15
                checks.append("Python syntax error detected")

        if re.search(r"\bdef |\bclass |\bfunction |=>", content):
            score += 10
            checks.append("Contains functions/classes")

        if re.search(r'#[^!]|//|/\*|"""', content):
            score += 10
            checks.append("Has comments/docstrings")

        if "try" in content and ("except" in content or "catch" in content):
            score += 10
            checks.append("Error handling present")

        if re.search(r"\btest_|assert |describe\(|it\(", content):
            score += 10
            checks.append("Includes tests")

        return {"score": max(0, min(score, 100)), "checks": checks}

    def score_documentation(self, content: str) -> Dict[str, Any]:
        if not content or not content.strip():
            return {"score": 0, "checks": ["No content produced"]}

        score = 30
        checks: List[str] = []
        if len(content) > 200:
            score += 15
            checks.append("Reasonable length")
        if re.search(r"^#+\s", content, re.MULTILINE):
            score += 15
            checks.append("Has headers")
        if "```" in content:
            score += 15
            checks.append("Has code blocks")
        if re.search(r"\[.+?\]\(.+?\)", content):
            score += 10
            checks.append("Has links")
        return {"score": min(score, 100), "checks": checks}


scorer = QualityScorer()
