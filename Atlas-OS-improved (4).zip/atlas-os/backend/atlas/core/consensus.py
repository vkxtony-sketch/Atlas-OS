"""Consensus Engine

Combines the outputs of multiple agent steps into one final result.
"""
from __future__ import annotations

from typing import Any, Dict, List


class ConsensusEngine:
    def aggregate(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        outputs = [r.get("output", "") for r in results if r.get("success") and r.get("output")]
        errors = [r.get("error", "") for r in results if not r.get("success")]
        combined = "\n\n".join(outputs) if outputs else "No successful outputs."
        return {
            "success": len(outputs) > 0,
            "output": combined,
            "errors": errors,
            "agent_count": len(results),
            "success_count": len(outputs),
        }


consensus = ConsensusEngine()
