"""Memory System

Long-lived state Atlas carries across goals and sessions, so it doesn't
have to be told the same things repeatedly and doesn't contradict earlier
decisions on the same project:

- User preferences: global key/value settings (e.g. test_framework=pytest,
  code_style=minimal_comments) folded into every plan.
- Project history: a timestamped event log per project -- goals completed,
  architecture notes raised during review, and any decisions recorded
  explicitly -- so a later goal on the same project has context on what
  was already decided, tried, or flagged.

Backed by the same SQLite file as projects (DB_PATH). This is a
single-user, single-box setup, so a lightweight embedded log is the right
amount of infrastructure -- no separate memory service needed.
"""
from __future__ import annotations

import datetime
import json
import uuid
from typing import Any, Dict, List, Optional

import aiosqlite

from atlas.config import DB_PATH

_SCHEMA = [
    """CREATE TABLE IF NOT EXISTS user_preferences (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
    )""",
    """CREATE TABLE IF NOT EXISTS project_history (
        id TEXT PRIMARY KEY,
        project_id TEXT NOT NULL,
        event_type TEXT NOT NULL,
        summary TEXT NOT NULL,
        metadata TEXT,
        created_at TEXT NOT NULL
    )""",
    "CREATE INDEX IF NOT EXISTS idx_project_history_project ON project_history(project_id)",
]


class MemoryStore:
    async def _db(self) -> aiosqlite.Connection:
        db = await aiosqlite.connect(DB_PATH)
        for stmt in _SCHEMA:
            await db.execute(stmt)
        await db.commit()
        return db

    # --- Preferences --------------------------------------------------
    async def set_preference(self, key: str, value: str) -> None:
        db = await self._db()
        now = datetime.datetime.now().isoformat()
        await db.execute(
            "INSERT INTO user_preferences (key, value, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at",
            (key, value, now),
        )
        await db.commit()
        await db.close()

    async def get_preference(self, key: str, default: Optional[str] = None) -> Optional[str]:
        db = await self._db()
        async with db.execute("SELECT value FROM user_preferences WHERE key = ?", (key,)) as cursor:
            row = await cursor.fetchone()
        await db.close()
        return row[0] if row else default

    async def all_preferences(self) -> Dict[str, str]:
        db = await self._db()
        async with db.execute("SELECT key, value FROM user_preferences") as cursor:
            rows = await cursor.fetchall()
        await db.close()
        return {k: v for k, v in rows}

    async def delete_preference(self, key: str) -> bool:
        db = await self._db()
        cursor = await db.execute("DELETE FROM user_preferences WHERE key = ?", (key,))
        await db.commit()
        deleted = cursor.rowcount > 0
        await db.close()
        return deleted

    # --- Project history / architecture decisions ----------------------
    async def record_event(
        self, project_id: str, event_type: str, summary: str, metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        event_id = str(uuid.uuid4())
        db = await self._db()
        await db.execute(
            "INSERT INTO project_history (id, project_id, event_type, summary, metadata, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (
                event_id,
                project_id,
                event_type,
                summary,
                json.dumps(metadata or {}),
                datetime.datetime.now().isoformat(),
            ),
        )
        await db.commit()
        await db.close()
        return event_id

    async def get_history(
        self, project_id: str, event_type: Optional[str] = None, limit: int = 50
    ) -> List[Dict[str, Any]]:
        db = await self._db()
        if event_type:
            query = (
                "SELECT id, project_id, event_type, summary, metadata, created_at FROM project_history "
                "WHERE project_id = ? AND event_type = ? ORDER BY created_at DESC LIMIT ?"
            )
            params: tuple = (project_id, event_type, limit)
        else:
            query = (
                "SELECT id, project_id, event_type, summary, metadata, created_at FROM project_history "
                "WHERE project_id = ? ORDER BY created_at DESC LIMIT ?"
            )
            params = (project_id, limit)
        async with db.execute(query, params) as cursor:
            rows = await cursor.fetchall()
        await db.close()
        return [
            {
                "id": r[0],
                "project_id": r[1],
                "event_type": r[2],
                "summary": r[3],
                "metadata": json.loads(r[4] or "{}"),
                "created_at": r[5],
            }
            for r in rows
        ]

    async def delete_event(self, event_id: str) -> bool:
        db = await self._db()
        cursor = await db.execute("DELETE FROM project_history WHERE id = ?", (event_id,))
        await db.commit()
        deleted = cursor.rowcount > 0
        await db.close()
        return deleted

    # --- Composed context for the planner -------------------------------
    async def build_context(self, project_id: Optional[str], max_events: int = 8) -> str:
        """A short text block folding in relevant preferences and recent
        project history, meant to be appended to a goal before planning."""
        parts: List[str] = []
        prefs = await self.all_preferences()
        if prefs:
            parts.append("User preferences to respect:\n" + "\n".join(f"- {k}: {v}" for k, v in prefs.items()))
        if project_id:
            history = await self.get_history(project_id, limit=max_events)
            if history:
                lines = [f"- [{h['event_type']}] {h['summary']}" for h in reversed(history)]
                parts.append("Relevant project history (oldest to newest):\n" + "\n".join(lines))
        return "\n\n".join(parts)


memory = MemoryStore()
