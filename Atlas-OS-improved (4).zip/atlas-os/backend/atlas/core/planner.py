"""Task Planner

Uses the local LLM to decompose a goal into an ordered, dependency-aware
list of agent steps. Falls back to a keyword heuristic if the model doesn't
return usable JSON (e.g. a very small/uncooperative local model).
"""
from __future__ import annotations

import json
import re
from typing import Any, Dict, List, Optional

from atlas.config import PLANNER_MODEL
from atlas.models.ollama_client import client
from atlas.utils.logger import logger

AGENT_CATALOG: Dict[str, str] = {
    "coding": "Writes, edits, and refactors code files in the project workspace.",
    "testing": "Writes tests and actually runs them (pytest, npm test, etc).",
    "security": "Read-only audit of code/config for vulnerabilities.",
    "documentation": "Writes README/API docs/comments and saves them.",
    "research": "Investigates a topic using the local knowledge base.",
    "knowledge": "Indexes and searches the project's knowledge base.",
    "performance": "Profiles and optimizes code.",
    "git": "Runs git operations (status, commit, branch, diff, etc).",
    "deployment": "Runs build/packaging commands.",
    "terminal": "Runs allowlisted shell commands in the workspace.",
    "executive": "General-purpose fallback for anything that doesn't fit another agent.",
}

_FALLBACK_RULES = [
    (("code", "build", "implement", "create", "add feature", "fix bug", "refactor"), ["coding", "testing"]),
    (("research", "find", "learn", "investigate"), ["research"]),
    (("deploy", "release", "ship", "package"), ["deployment"]),
    (("document", "readme", "docs"), ["documentation"]),
    (("test",), ["testing"]),
    (("security", "audit", "vulnerab"), ["security"]),
    (("git", "commit", "branch"), ["git"]),
    (("optimi", "performance", "speed up", "profile"), ["performance"]),
]


class TaskPlanner:
    async def plan(self, goal: str) -> List[Dict[str, Any]]:
        steps = await self._plan_with_llm(goal)
        if steps:
            return steps
        logger.warning("Planner LLM output was unusable; falling back to keyword heuristic.")
        return self._fallback_plan(goal)

    async def _plan_with_llm(self, goal: str) -> Optional[List[Dict[str, Any]]]:
        catalog = "\n".join(f"- {name}: {desc}" for name, desc in AGENT_CATALOG.items())
        system = (
            "You are the planning module of Atlas OS. Break the user's goal into an "
            "ordered list of concrete steps, each assigned to exactly one specialist agent.\n\n"
            f"Available agents:\n{catalog}\n\n"
            "Respond with ONLY a JSON array, no prose before or after, in this exact shape:\n"
            '[{"agent": "coding", "task": "specific self-contained instructions for this step", "depends_on": []}]\n'
            "depends_on lists the zero-based indices of steps whose output this step needs first. "
            "Use 1 to 6 steps. Prefer the most specific agent; only use 'executive' if truly nothing else fits."
        )
        try:
            result = await client.generate(PLANNER_MODEL, goal, system=system, temperature=0.2)
            raw = result.get("response", "")
        except Exception as e:
            logger.error(f"Planner call failed: {e}")
            return None

        match = re.search(r"\[.*\]", raw, re.DOTALL)
        if not match:
            return None
        try:
            steps = json.loads(match.group(0))
        except json.JSONDecodeError:
            return None
        if not isinstance(steps, list) or not steps:
            return None

        cleaned: List[Dict[str, Any]] = []
        for i, step in enumerate(steps):
            if not isinstance(step, dict):
                continue
            agent = str(step.get("agent", "")).strip()
            task = str(step.get("task", "")).strip()
            if agent not in AGENT_CATALOG or not task:
                continue
            depends_on = step.get("depends_on", [])
            if not isinstance(depends_on, list):
                depends_on = []
            depends_on = [d for d in depends_on if isinstance(d, int) and 0 <= d < i]
            cleaned.append({"agent": agent, "task": task, "depends_on": depends_on})

        return cleaned or None

    def _fallback_plan(self, goal: str) -> List[Dict[str, Any]]:
        goal_lower = goal.lower()
        for keywords, agents in _FALLBACK_RULES:
            if any(k in goal_lower for k in keywords):
                steps = []
                for i, agent in enumerate(agents):
                    steps.append({"agent": agent, "task": goal, "depends_on": [i - 1] if i > 0 else []})
                return steps
        return [{"agent": "executive", "task": goal, "depends_on": []}]


planner = TaskPlanner()
