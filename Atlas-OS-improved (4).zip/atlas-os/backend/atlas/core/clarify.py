"""Clarifying Questions

Before committing to a plan, ask the planner model one extra question:
"is this actually specified well enough to build?" Small/ambiguous goals
("add auth", "make it faster") tend to get a much better result if a human
answers 2-3 pointed questions first, instead of the system silently
guessing and building the wrong thing.

Kept conservative on purpose -- this should fire for genuinely
under-specified goals, not for every request, or it becomes an annoying
gate instead of a useful one.
"""
from __future__ import annotations

import json
import re
from typing import List

from atlas.config import PLANNER_MODEL
from atlas.models.ollama_client import client
from atlas.utils.logger import logger


async def needs_clarification(goal: str, max_questions: int = 3) -> List[str]:
    system = (
        "You are the clarification-check for a coding assistant. Given a user's goal, decide "
        "whether it is under-specified enough that you'd genuinely build the wrong thing without "
        "asking first (e.g. missing tech stack, missing scope/behavior for an ambiguous feature, "
        "missing target framework/language). Do NOT ask questions just to be thorough -- only ask "
        "if proceeding without an answer would likely produce the wrong result.\n\n"
        "Respond with ONLY a JSON array of question strings (empty array if no clarification is "
        f"needed). Maximum {max_questions} questions."
    )
    try:
        result = await client.generate(PLANNER_MODEL, goal, system=system, temperature=0.2)
        raw = result.get("response", "")
    except Exception as e:
        logger.error(f"Clarification check failed: {e}")
        return []

    match = re.search(r"\[.*\]", raw, re.DOTALL)
    if not match:
        return []
    try:
        questions = json.loads(match.group(0))
    except json.JSONDecodeError:
        return []
    if not isinstance(questions, list):
        return []

    cleaned = [str(q).strip() for q in questions if str(q).strip()]
    return cleaned[:max_questions]
