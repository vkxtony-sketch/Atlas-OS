"""Atlas OS Configuration"""
import os
from pathlib import Path

BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

OLLAMA_HOST = os.getenv("ATLAS_OLLAMA_HOST", "http://127.0.0.1:11434")
API_PORT = int(os.getenv("ATLAS_API_PORT", "8472"))
DB_PATH = str(DATA_DIR / "atlas.db")
CHROMA_PATH = str(DATA_DIR / "chroma")

# Every project gets its own sandboxed working directory under here. Agents
# with filesystem/shell tools are confined to their project's directory.
WORKSPACE_DIR = os.getenv("ATLAS_WORKSPACE_DIR", str(DATA_DIR / "workspaces"))
Path(WORKSPACE_DIR).mkdir(parents=True, exist_ok=True)

# Model used by the planner to decompose goals into agent steps. Keep this
# fast/small since it runs on every goal submission. Defaults below are tuned
# for a modest CPU-only box (no GPU, ~12GB RAM, no AVX2): a 3B model is the
# sweet spot of speed and quality. Bump these in .env once you're on beefier
# hardware or serving a GPU-backed model.
PLANNER_MODEL = os.getenv("ATLAS_PLANNER_MODEL", "llama3.2")

DEFAULT_TEMPERATURE = 0.7
# Kept low by default because a single CPU-only host chokes fast when
# multiple Ollama calls land at once. atlas/hardware.py computes a
# recommended_concurrency from live RAM at /api/v1/hardware/profile --
# treat this env var as a manual override once you've checked that value.
MAX_CONCURRENCY = int(os.getenv("ATLAS_MAX_CONCURRENCY", "1"))
AGENT_MAX_ITERATIONS = int(os.getenv("ATLAS_AGENT_MAX_ITERATIONS", "6"))

# Review/consensus loop: how many reviewer passes get run in parallel against
# combined output, and how many revision rounds are allowed before Atlas
# just ships the best version it has with the remaining issues attached.
REVIEW_MODEL = os.getenv("ATLAS_REVIEW_MODEL", "llama3.2")
MAX_REVISION_ROUNDS = int(os.getenv("ATLAS_MAX_REVISION_ROUNDS", "1"))

# ---------------------------------------------------------------------------
# Branding
# ---------------------------------------------------------------------------
# What your API calls itself in responses, docs, and the system prompt
# prepended to every chat/generate call. Change these in .env to rebrand
# without touching code.
BRAND_NAME = os.getenv("ATLAS_BRAND_NAME", "Atlas OS")
BRAND_TAGLINE = os.getenv("ATLAS_BRAND_TAGLINE", "Your own local AI, self-hosted.")
BRAND_SYSTEM_PROMPT = os.getenv(
    "ATLAS_BRAND_SYSTEM_PROMPT",
    f"You are {BRAND_NAME}, a self-hosted assistant. Be direct, helpful, and concise.",
)

# ---------------------------------------------------------------------------
# API key auth
# ---------------------------------------------------------------------------
# Comma-separated list of accepted keys, e.g. ATLAS_API_KEYS=key_abc,key_def
# Also readable from a JSON file (one string per line) so you don't have to
# put real keys in shell history / .env. See atlas/api/auth.py and
# scripts/generate_api_key.py.
API_KEYS_ENV = os.getenv("ATLAS_API_KEYS", "")
API_KEYS_FILE = str(DATA_DIR / "api_keys.txt")
# Set to "false" to disable auth entirely (e.g. pure local dev on localhost).
AUTH_ENABLED = os.getenv("ATLAS_AUTH_ENABLED", "true").lower() != "false"

# ---------------------------------------------------------------------------
# Rate limiting
# ---------------------------------------------------------------------------
# Requests allowed per API key per rolling 60s window. Kept conservative
# because MAX_CONCURRENCY=1 means requests queue behind each other anyway on
# CPU-only hardware -- this just stops one key from starving everyone else.
RATE_LIMIT_PER_MINUTE = int(os.getenv("ATLAS_RATE_LIMIT_PER_MINUTE", "20"))

# ---------------------------------------------------------------------------
# Multi-model debate (coding tasks)
# ---------------------------------------------------------------------------
# When enabled, coding steps aren't answered by a single model. Instead every
# model in DEBATE_MODELS independently proposes a solution to the same
# prompt, then each sees the others' (anonymized) solutions and revises --
# repeating until they converge on essentially the same answer or
# DEBATE_MAX_ROUNDS is hit. Only the final, agreed-upon solution is shown to
# the user; the back-and-forth stays internal (available in the response's
# `debate` field if you want to inspect it).
#
# Models run ONE AT A TIME per round (not concurrently) -- on CPU-only
# hardware with no GPU, running 3 models at once would thrash and be slower
# overall than running them in sequence. If you have a beefier box, this is
# the first thing to change (see atlas/core/debate.py).
DEBATE_ENABLED = os.getenv("ATLAS_DEBATE_ENABLED", "true").lower() != "false"
DEBATE_MODELS = [m.strip() for m in os.getenv("ATLAS_DEBATE_MODELS", "llama3.2,qwen2.5,mistral").split(",") if m.strip()]
DEBATE_MAX_ROUNDS = int(os.getenv("ATLAS_DEBATE_MAX_ROUNDS", "3"))
# Pairwise similarity (0-1, via difflib) above which candidate solutions are
# considered "in agreement" and the debate stops early.
DEBATE_AGREEMENT_THRESHOLD = float(os.getenv("ATLAS_DEBATE_AGREEMENT_THRESHOLD", "0.85"))

# ---------------------------------------------------------------------------
# "Work until done" project iteration
# ---------------------------------------------------------------------------
# After the normal plan -> build -> review -> revise pass, Atlas checks the
# result against QUALITY_THRESHOLD and whether any blocking issues remain.
# If it's not good enough yet, it loops back and tries again (re-planning
# with the accumulated feedback as extra context) up to
# MAX_PROJECT_ITERATIONS times, instead of quitting after one pass.
MAX_PROJECT_ITERATIONS = int(os.getenv("ATLAS_MAX_PROJECT_ITERATIONS", "3"))
QUALITY_THRESHOLD = int(os.getenv("ATLAS_QUALITY_THRESHOLD", "70"))

# ---------------------------------------------------------------------------
# Clarifying questions
# ---------------------------------------------------------------------------
# Before planning, Atlas asks the planner model whether the goal is
# under-specified enough to be worth pausing for. Set to false to always
# barrel ahead and make its own assumptions instead.
CLARIFY_ENABLED = os.getenv("ATLAS_CLARIFY_ENABLED", "true").lower() != "false"
CLARIFY_MAX_QUESTIONS = int(os.getenv("ATLAS_CLARIFY_MAX_QUESTIONS", "3"))
