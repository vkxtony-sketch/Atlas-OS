#!/usr/bin/env python
"""Generate a new API key for your branded Atlas OS API.

Usage:
    cd backend
    python scripts/generate_api_key.py [prefix]

The key is appended to backend/data/api_keys.txt and printed once. Give it
to whichever app/client should be allowed to call your API, in an
`Authorization: Bearer <key>` header. Keys are picked up live -- no server
restart needed.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from atlas.api.auth import generate_key  # noqa: E402

if __name__ == "__main__":
    prefix = sys.argv[1] if len(sys.argv) > 1 else "atlas"
    key = generate_key(prefix)
    print("New API key generated (save it now, it won't be shown again):\n")
    print(f"  {key}\n")
    print("Use it as:  Authorization: Bearer " + key)
