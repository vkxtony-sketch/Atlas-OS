import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Chat from './pages/Chat'
import Agents from './pages/Agents'
import Models from './pages/Models'
import Knowledge from './pages/Knowledge'
import Projects from './pages/Projects'
import Hardware from './pages/Hardware'
import Settings from './pages/Settings'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/chat" element={<Chat />} />
        <Route path="/agents" element={<Agents />} />
        <Route path="/models" element={<Models />} />
        <Route path="/knowledge" element={<Knowledge />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/hardware" element={<Hardware />} />
        <Route path="/settings" element={<Settings />} />
      </Routes>
    </Layout>
  )
}

export default App
