export interface HardwareProfile {
  cpu: { name: string; cores_physical: number; cores_logical: number; frequency_mhz: any; architecture: string; };
  ram: { total_mb: number; available_mb: number; used_mb: number; percent_used: number; };
  gpu: { count: number; has_gpu: boolean; total_vram_mb: number; devices: Array<{ index: number; name: string; total_memory_mb: number; free_memory_mb: number; used_memory_mb: number; utilization_percent: number; }>; };
  storage: { total_gb: number; free_gb: number; };
  os: { name: string; version: string; architecture: string; };
  capabilities: { can_run_large_models: boolean; can_run_medium_models: boolean; can_run_small_models: boolean; recommended_concurrency: number; };
}

export interface ModelInfo {
  id: string; name: string; size: string; parameters: string;
  required_ram_mb: number; required_vram_mb: number;
  capabilities: string[]; description: string; tags: string[];
  context_length: number; recommended_temperature: number;
}

export interface AgentInfo {
  name: string; description: string; capabilities: string[]; status: string;
}

export interface ChatMessage {
  role: 'user' | 'assistant' | 'system'; content: string; timestamp?: string;
}

export interface Project {
  id: string; name: string; description: string; goal: string;
  status: string; created_at: string; updated_at: string; directory: string;
}

export interface WorkflowEvent {
  type: string; stage?: number; message?: string; plan?: any; task?: any;
  agent?: string; success?: boolean; output_preview?: string;
  output?: string; quality_score?: number;
}
