import { Link, useLocation } from 'react-router-dom'
import { LayoutDashboard, MessageSquare, Bot, Brain, Database, FolderKanban, Cpu, Settings, Globe } from 'lucide-react'
import { ReactNode } from 'react'

const navItems = [
  { path: '/', icon: LayoutDashboard, label: 'Dashboard' },
  { path: '/chat', icon: MessageSquare, label: 'Chat' },
  { path: '/agents', icon: Bot, label: 'Agents' },
  { path: '/models', icon: Brain, label: 'Models' },
  { path: '/knowledge', icon: Database, label: 'Knowledge' },
  { path: '/projects', icon: FolderKanban, label: 'Projects' },
  { path: '/hardware', icon: Cpu, label: 'Hardware' },
  { path: '/settings', icon: Settings, label: 'Settings' },
]

interface LayoutProps { children: ReactNode }

export default function Layout({ children }: LayoutProps) {
  const location = useLocation()
  return (
    <div className="flex h-screen bg-dark-950">
      <aside className="w-64 bg-dark-900 border-r border-dark-800 flex flex-col">
        <div className="p-6 border-b border-dark-800">
          <div className="flex items-center gap-3">
            <Globe className="w-8 h-8 text-atlas-500" />
            <div>
              <h1 className="text-xl font-bold text-white">Atlas OS</h1>
              <p className="text-xs text-dark-500">AI Operating System</p>
            </div>
          </div>
        </div>
        <nav className="flex-1 p-4 space-y-1">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path
            return (
              <Link key={item.path} to={item.path}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-lg transition-colors ${
                  isActive ? 'bg-atlas-600/20 text-atlas-400 border border-atlas-600/30' : 'text-dark-400 hover:text-dark-200 hover:bg-dark-800'
                }`}>
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            )
          })}
        </nav>
        <div className="p-4 border-t border-dark-800">
          <div className="flex items-center gap-2 text-xs text-dark-500">
            <div className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>System Online</span>
          </div>
        </div>
      </aside>
      <main className="flex-1 overflow-auto">{children}</main>
    </div>
  )
}
