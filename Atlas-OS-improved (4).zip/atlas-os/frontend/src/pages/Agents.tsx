import { useEffect, useState } from 'react'
import { Bot, Play, Activity, AlertCircle } from 'lucide-react'
import api from '../services/api'

export default function Agents() {
  const [agents, setAgents] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.listAgents().then(res => { if (res.success) setAgents(res.agents) }).finally(() => setLoading(false))
  }, [])

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <header className="mb-8"><h2 className="text-3xl font-bold text-white">AI Agents</h2><p className="text-dark-400 mt-1">Specialized agents for different tasks</p></header>
      {loading ? <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-atlas-500" /></div> : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {agents.map((agent) => <AgentCard key={agent.name} agent={agent} />)}
        </div>
      )}
    </div>
  )
}

function AgentCard({ agent }: { agent: any }) {
  const [executing, setExecuting] = useState(false)
  const [result, setResult] = useState<string | null>(null)

  const handleExecute = async () => {
    setExecuting(true)
    try { const res = await api.executeAgent(agent.name, 'Status check'); setResult(res.success ? 'Online' : res.error) }
    catch (e) { setResult('Error') } finally { setExecuting(false) }
  }

  return (
    <div className="atlas-card hover:border-atlas-600/30 transition-colors">
      <div className="flex items-start justify-between mb-4">
        <div className="w-12 h-12 rounded-xl bg-atlas-600/10 flex items-center justify-center"><Bot className="w-6 h-6 text-atlas-400" /></div>
        <span className={`flex items-center gap-1.5 text-xs ${executing ? 'text-amber-400' : 'text-emerald-400'}`}><Activity className="w-3 h-3" />{executing ? 'Busy' : 'Idle'}</span>
      </div>
      <h3 className="text-lg font-semibold text-white capitalize">{agent.name}</h3>
      <p className="text-sm text-dark-400 mt-1">{agent.description}</p>
      <div className="mt-4 flex flex-wrap gap-2">
        {agent.capabilities?.slice(0, 3).map((cap: string) => <span key={cap} className="text-xs px-2 py-1 rounded-full bg-dark-800 text-dark-400 border border-dark-700">{cap.replace(/_/g, ' ')}</span>)}
      </div>
      <div className="mt-4 pt-4 border-t border-dark-800 flex gap-2">
        <button onClick={handleExecute} disabled={executing} className="atlas-button text-sm flex items-center gap-2"><Play className="w-4 h-4" />Test</button>
        {result && <span className="flex items-center gap-1 text-sm text-dark-400"><AlertCircle className="w-4 h-4" />{result}</span>}
      </div>
    </div>
  )
}
