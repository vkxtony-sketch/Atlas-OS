import { useEffect, useState } from 'react'
import { FolderKanban, Plus, Clock, Target } from 'lucide-react'
import api from '../services/api'
import type { Project } from '../types'

export default function Projects() {
  const [projects, setProjects] = useState<Project[]>([])
  const [showNew, setShowNew] = useState(false)
  const [newName, setNewName] = useState('')
  const [newDesc, setNewDesc] = useState('')
  const [newGoal, setNewGoal] = useState('')

  useEffect(() => { loadProjects() }, [])
  const loadProjects = () => { api.listProjects().then(res => { if (res.success) setProjects(res.projects) }) }
  const createProject = async () => {
    if (!newName.trim()) return
    const res = await api.createProject(newName, newDesc, newGoal)
    if (res.success) { setShowNew(false); setNewName(''); setNewDesc(''); setNewGoal(''); loadProjects() }
  }

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <header className="mb-8 flex items-center justify-between">
        <div><h2 className="text-3xl font-bold text-white">Projects</h2><p className="text-dark-400 mt-1">Manage your AI-assisted projects</p></div>
        <button onClick={() => setShowNew(true)} className="atlas-button flex items-center gap-2"><Plus className="w-4 h-4" />New Project</button>
      </header>
      {showNew && (
        <div className="atlas-card mb-6">
          <h3 className="text-lg font-semibold text-white mb-4">Create New Project</h3>
          <div className="space-y-4">
            <input type="text" value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Project name" className="atlas-input w-full" />
            <input type="text" value={newDesc} onChange={(e) => setNewDesc(e.target.value)} placeholder="Description (optional)" className="atlas-input w-full" />
            <textarea value={newGoal} onChange={(e) => setNewGoal(e.target.value)} placeholder="Project goal - what do you want to build?" className="atlas-input w-full h-24 resize-none" />
            <div className="flex gap-3"><button onClick={createProject} className="atlas-button">Create</button><button onClick={() => setShowNew(false)} className="atlas-button-outline">Cancel</button></div>
          </div>
        </div>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project) => (
          <div key={project.id} className="atlas-card hover:border-atlas-600/30 transition-colors">
            <div className="w-12 h-12 rounded-xl bg-atlas-600/10 flex items-center justify-center mb-4"><FolderKanban className="w-6 h-6 text-atlas-400" /></div>
            <h3 className="text-lg font-semibold text-white">{project.name}</h3>
            <p className="text-sm text-dark-400 mt-1 line-clamp-2">{project.description}</p>
            {project.goal && <div className="mt-3 flex items-start gap-2"><Target className="w-4 h-4 text-atlas-400 mt-0.5 flex-shrink-0" /><p className="text-xs text-dark-500 line-clamp-2">{project.goal}</p></div>}
            <div className="mt-4 pt-4 border-t border-dark-800 flex items-center gap-2 text-xs text-dark-500"><Clock className="w-3 h-3" />{new Date(project.created_at).toLocaleDateString()}</div>
          </div>
        ))}
      </div>
      {projects.length === 0 && <div className="text-center py-16"><FolderKanban className="w-16 h-16 text-dark-700 mx-auto mb-4" /><p className="text-dark-500">No projects yet. Create one to get started.</p></div>}
    </div>
  )
}
