import { useState } from 'react'
import { Settings as SettingsIcon, Shield, Terminal, GitBranch, Rocket, Save } from 'lucide-react'

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    requireApproval: true, allowTerminal: false, allowGit: false, allowDeploy: false,
    defaultModel: 'llama3.2', temperature: 0.7, maxConcurrency: 3,
  })

  const handleSave = () => { alert('Settings saved!') }

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <header className="mb-8"><h2 className="text-3xl font-bold text-white">Settings</h2><p className="text-dark-400 mt-1">Configure Atlas OS behavior</p></header>
      <div className="space-y-6">
        <div className="atlas-card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Shield className="w-5 h-5 text-atlas-400" />Security</h3>
          <div className="space-y-4">
            <ToggleSetting label="Require user approval for sensitive actions" description="Atlas will ask before executing commands that affect your system" enabled={settings.requireApproval} onChange={(v) => setSettings(s => ({ ...s, requireApproval: v }))} />
          </div>
        </div>
        <div className="atlas-card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Terminal className="w-5 h-5 text-atlas-400" />Permissions</h3>
          <div className="space-y-4">
            <ToggleSetting label="Allow terminal commands" description="Enable Atlas to execute local shell commands" enabled={settings.allowTerminal} onChange={(v) => setSettings(s => ({ ...s, allowTerminal: v }))} />
            <ToggleSetting label="Allow Git operations" description="Enable Atlas to manage Git repositories" enabled={settings.allowGit} onChange={(v) => setSettings(s => ({ ...s, allowGit: v }))} />
            <ToggleSetting label="Allow deployment" description="Enable Atlas to deploy applications" enabled={settings.allowDeploy} onChange={(v) => setSettings(s => ({ ...s, allowDeploy: v }))} />
          </div>
        </div>
        <div className="atlas-card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><SettingsIcon className="w-5 h-5 text-atlas-400" />AI Configuration</h3>
          <div className="space-y-4">
            <div><label className="block text-sm font-medium text-dark-300 mb-2">Default Model</label>
              <select value={settings.defaultModel} onChange={(e) => setSettings(s => ({ ...s, defaultModel: e.target.value }))} className="atlas-input w-full">
                <option value="llama3.2">Llama 3.2</option><option value="qwen2.5">Qwen 2.5</option><option value="mistral">Mistral</option><option value="deepseek-coder-v2">DeepSeek Coder V2</option>
              </select>
            </div>
            <div><label className="block text-sm font-medium text-dark-300 mb-2">Temperature: {settings.temperature}</label><input type="range" min="0" max="2" step="0.1" value={settings.temperature} onChange={(e) => setSettings(s => ({ ...s, temperature: parseFloat(e.target.value) }))} className="w-full accent-atlas-500" /></div>
            <div><label className="block text-sm font-medium text-dark-300 mb-2">Max Concurrent Models: {settings.maxConcurrency}</label><input type="range" min="1" max="8" step="1" value={settings.maxConcurrency} onChange={(e) => setSettings(s => ({ ...s, maxConcurrency: parseInt(e.target.value) }))} className="w-full accent-atlas-500" /></div>
          </div>
        </div>
        <button onClick={handleSave} className="atlas-button flex items-center gap-2"><Save className="w-4 h-4" />Save Settings</button>
      </div>
    </div>
  )
}

function ToggleSetting({ label, description, enabled, onChange }: { label: string; description: string; enabled: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between">
      <div><div className="text-sm font-medium text-dark-200">{label}</div><div className="text-xs text-dark-500 mt-0.5">{description}</div></div>
      <button onClick={() => onChange(!enabled)} className={`relative w-12 h-6 rounded-full transition-colors ${enabled ? 'bg-atlas-500' : 'bg-dark-700'}`}>
        <div className={`absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform ${enabled ? 'translate-x-6' : 'translate-x-0.5'}`} />
      </button>
    </div>
  )
}
