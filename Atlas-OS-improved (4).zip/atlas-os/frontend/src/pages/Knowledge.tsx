import { useState } from 'react'
import { Database, Search, Upload, FileText } from 'lucide-react'
import api from '../services/api'

export default function Knowledge() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<any[]>([])
  const [searching, setSearching] = useState(false)

  const handleSearch = async () => {
    if (!query.trim()) return
    setSearching(true)
    try { const res = await api.searchKnowledge(query); if (res.success) setResults(res.results) } finally { setSearching(false) }
  }

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <header className="mb-8"><h2 className="text-3xl font-bold text-white">Knowledge Base</h2><p className="text-dark-400 mt-1">Search and manage your indexed documents</p></header>
      <div className="atlas-card mb-6">
        <div className="flex gap-3">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-dark-500" />
            <input type="text" value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSearch()} placeholder="Search knowledge base..." className="atlas-input w-full pl-10" />
          </div>
          <button onClick={handleSearch} disabled={searching} className="atlas-button flex items-center gap-2">{searching ? 'Searching...' : 'Search'}</button>
        </div>
      </div>
      {results.length > 0 && <div className="space-y-4">{results.map((result, i) => (
        <div key={i} className="atlas-card">
          <div className="flex items-start gap-3">
            <FileText className="w-5 h-5 text-atlas-400 mt-0.5" />
            <div>
              <p className="text-sm text-dark-200">{result.content}</p>
              <div className="flex items-center gap-4 mt-2 text-xs text-dark-500"><span>Relevance: {(result.distance * 100).toFixed(1)}%</span><span>Source: {result.metadata?.file_name || 'Unknown'}</span></div>
            </div>
          </div>
        </div>
      ))}</div>}
      {results.length === 0 && !searching && (
        <div className="text-center py-16">
          <Database className="w-16 h-16 text-dark-700 mx-auto mb-4" />
          <p className="text-dark-500">Search your knowledge base or upload documents</p>
          <button className="atlas-button-outline mt-4 flex items-center gap-2 mx-auto"><Upload className="w-4 h-4" />Upload Document</button>
        </div>
      )}
    </div>
  )
}
