import { useEffect, useState } from 'react'
import { Cpu, MemoryStick, HardDrive, Brain, Activity, Zap, Shield, Code, MessageSquare } from 'lucide-react'
import api from '../services/api'
import type { HardwareProfile } from '../types'

export default function Dashboard() {
  const [hardware, setHardware] = useState<HardwareProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.getHardwareProfile().then((res) => { if (res.success) setHardware(res.profile) }).finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="flex items-center justify-center h-full"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-atlas-500" /></div>

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <header className="mb-8"><h2 className="text-3xl font-bold text-white">Dashboard</h2><p className="text-dark-400 mt-1">Atlas OS system overview</p></header>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard icon={Cpu} label="CPU" value={hardware?.cpu.name || 'Unknown'} subtext={`${hardware?.cpu.cores_logical || 0} cores`} color="text-blue-400" />
        <StatCard icon={MemoryStick} label="RAM" value={`${Math.round((hardware?.ram.total_mb || 0) / 1024)} GB`} subtext={`${hardware?.ram.percent_used.toFixed(1)}% used`} color="text-emerald-400" />
        <StatCard icon={HardDrive} label="Storage" value={`${hardware?.storage.free_gb || 0} GB`} subtext={`${hardware?.storage.total_gb || 0} GB total`} color="text-amber-400" />
        <StatCard icon={Brain} label="GPU" value={hardware?.gpu.count ? `${hardware.gpu.count} device(s)` : 'None'} subtext={hardware?.gpu.devices[0]?.name || 'No GPU detected'} color="text-purple-400" />
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="atlas-card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Zap className="w-5 h-5 text-atlas-400" />System Capabilities</h3>
          <div className="space-y-3">
            <CapabilityRow label="Large Models (>30B)" enabled={hardware?.capabilities.can_run_large_models || false} />
            <CapabilityRow label="Medium Models (7-30B)" enabled={hardware?.capabilities.can_run_medium_models || false} />
            <CapabilityRow label="Small Models (<7B)" enabled={hardware?.capabilities.can_run_small_models || false} />
          </div>
          <div className="mt-4 pt-4 border-t border-dark-800"><p className="text-sm text-dark-400">Recommended concurrency: <span className="text-atlas-400 font-medium">{hardware?.capabilities.recommended_concurrency || 1}</span> models</p></div>
        </div>
        <div className="atlas-card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Activity className="w-5 h-5 text-atlas-400" />Quick Actions</h3>
          <div className="grid grid-cols-2 gap-3">
            <QuickAction icon={MessageSquare} label="New Chat" path="/chat" />
            <QuickAction icon={Code} label="New Project" path="/projects" />
            <QuickAction icon={Shield} label="Security Audit" path="/agents" />
            <QuickAction icon={Brain} label="Model Manager" path="/models" />
          </div>
        </div>
      </div>
    </div>
  )
}

function StatCard({ icon: Icon, label, value, subtext, color }: any) {
  return <div className="atlas-card"><div className="flex items-center justify-between mb-3"><Icon className={`w-6 h-6 ${color}`} /><span className="text-xs text-dark-500 uppercase tracking-wider">{label}</span></div><div className="text-xl font-bold text-white truncate">{value}</div><div className="text-sm text-dark-400 mt-1">{subtext}</div></div>
}

function CapabilityRow({ label, enabled }: { label: string; enabled: boolean }) {
  return <div className="flex items-center justify-between"><span className="text-dark-300">{label}</span><span className={`text-sm font-medium ${enabled ? 'text-emerald-400' : 'text-red-400'}`}>{enabled ? 'Supported' : 'Not Supported'}</span></div>
}

function QuickAction({ icon: Icon, label, path }: any) {
  return <a href={path} className="flex items-center gap-3 p-3 rounded-lg bg-dark-800 hover:bg-dark-700 transition-colors"><Icon className="w-5 h-5 text-atlas-400" /><span className="text-sm font-medium text-dark-200">{label}</span></a>
}
