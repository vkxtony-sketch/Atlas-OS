import { useState, useRef, useEffect } from 'react'
import { Send, Bot, User, Loader2 } from 'lucide-react'
import api from '../services/api'
import type { ChatMessage } from '../types'

export default function Chat() {
  const [messages, setMessages] = useState<ChatMessage[]>([{ role: 'assistant', content: 'Hello! I am Atlas OS. How can I help you today?' }])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }
  useEffect(() => { scrollToBottom() }, [messages])

  const sendMessage = async () => {
    if (!input.trim() || loading) return
    const userMessage: ChatMessage = { role: 'user', content: input.trim() }
    setMessages(prev => [...prev, userMessage])
    setInput('')
    setLoading(true)
    try {
      const response = await api.chat([...messages.map(m => ({ role: m.role, content: m.content })), { role: 'user', content: userMessage.content }])
      if (response.success) setMessages(prev => [...prev, { role: 'assistant', content: response.response, timestamp: new Date().toISOString() }])
      else throw new Error(response.error || 'Failed')
    } catch (error) {
      setMessages(prev => [...prev, { role: 'assistant', content: `Error: ${error instanceof Error ? error.message : 'Unknown'}`, timestamp: new Date().toISOString() }])
    } finally { setLoading(false) }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage() } }

  return (
    <div className="flex flex-col h-screen">
      <div className="border-b border-dark-800 p-4 bg-dark-900"><h2 className="text-xl font-bold text-white">Chat</h2><p className="text-sm text-dark-500">Talk with Atlas AI</p></div>
      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {messages.map((message, index) => (
          <div key={index} className={`flex gap-4 ${message.role === 'user' ? 'justify-end' : ''}`}>
            {message.role === 'assistant' && <div className="w-8 h-8 rounded-lg bg-atlas-600/20 flex items-center justify-center flex-shrink-0"><Bot className="w-5 h-5 text-atlas-400" /></div>}
            <div className={`max-w-3xl rounded-xl px-5 py-3 ${message.role === 'user' ? 'bg-atlas-600 text-white' : 'bg-dark-800 text-dark-100 border border-dark-700'}`}>
              <div className="whitespace-pre-wrap text-sm leading-relaxed">{message.content}</div>
            </div>
            {message.role === 'user' && <div className="w-8 h-8 rounded-lg bg-dark-700 flex items-center justify-center flex-shrink-0"><User className="w-5 h-5 text-dark-300" /></div>}
          </div>
        ))}
        {loading && <div className="flex gap-4"><div className="w-8 h-8 rounded-lg bg-atlas-600/20 flex items-center justify-center"><Loader2 className="w-5 h-5 text-atlas-400 animate-spin" /></div><div className="bg-dark-800 border border-dark-700 rounded-xl px-5 py-3"><span className="text-sm text-dark-400">Thinking...</span></div></div>}
        <div ref={messagesEndRef} />
      </div>
      <div className="border-t border-dark-800 p-4 bg-dark-900">
        <div className="max-w-4xl mx-auto flex gap-3">
          <textarea value={input} onChange={(e) => setInput(e.target.value)} onKeyDown={handleKeyDown} placeholder="Ask Atlas anything..." className="atlas-input flex-1 resize-none h-12 max-h-32" rows={1} />
          <button onClick={sendMessage} disabled={loading || !input.trim()} className="atlas-button flex items-center gap-2"><Send className="w-4 h-4" />Send</button>
        </div>
      </div>
    </div>
  )
}
