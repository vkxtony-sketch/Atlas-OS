import { useEffect, useState } from 'react'
import { Cpu, MemoryStick, HardDrive, Monitor, Activity } from 'lucide-react'
import api from '../services/api'
import type { HardwareProfile } from '../types'

export default function Hardware() {
  const [profile, setProfile] = useState<HardwareProfile | null>(null)
  const [resources, setResources] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([api.getHardwareProfile(), api.getResources()]).then(([pRes, rRes]) => {
      if (pRes.success) setProfile(pRes.profile)
      if (rRes.success) setResources(rRes.resources)
    }).finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="flex items-center justify-center h-full"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-atlas-500" /></div>

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <header className="mb-8"><h2 className="text-3xl font-bold text-white">Hardware</h2><p className="text-dark-400 mt-1">System resources and capabilities</p></header>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="atlas-card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Cpu className="w-5 h-5 text-atlas-400" />CPU</h3>
          <div className="space-y-3">
            <InfoRow label="Name" value={profile?.cpu.name} />
            <InfoRow label="Architecture" value={profile?.cpu.architecture} />
            <InfoRow label="Physical Cores" value={profile?.cpu.cores_physical} />
            <InfoRow label="Logical Cores" value={profile?.cpu.cores_logical} />
            <InfoRow label="Frequency" value={`${profile?.cpu.frequency_mhz} MHz`} />
          </div>
        </div>
        <div className="atlas-card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><MemoryStick className="w-5 h-5 text-atlas-400" />Memory</h3>
          <div className="space-y-3">
            <InfoRow label="Total" value={`${Math.round((profile?.ram.total_mb || 0) / 1024)} GB`} />
            <InfoRow label="Available" value={`${Math.round((profile?.ram.available_mb || 0) / 1024)} GB`} />
            <InfoRow label="Used" value={`${Math.round((profile?.ram.used_mb || 0) / 1024)} GB`} />
            <div className="mt-4">
              <div className="flex justify-between text-sm mb-1"><span className="text-dark-400">Usage</span><span className="text-dark-200">{profile?.ram.percent_used.toFixed(1)}%</span></div>
              <div className="h-2 bg-dark-800 rounded-full overflow-hidden"><div className="h-full bg-atlas-500 rounded-full transition-all" style={{ width: `${profile?.ram.percent_used || 0}%` }} /></div>
            </div>
          </div>
        </div>
        <div className="atlas-card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Monitor className="w-5 h-5 text-atlas-400" />GPU</h3>
          {profile?.gpu.has_gpu ? <div className="space-y-4">{profile.gpu.devices.map((gpu) => (
            <div key={gpu.index} className="p-3 rounded-lg bg-dark-800 border border-dark-700">
              <div className="font-medium text-dark-200">{gpu.name}</div>
              <div className="grid grid-cols-2 gap-2 mt-2 text-sm">
                <InfoRow label="Total VRAM" value={`${gpu.total_memory_mb} MB`} />
                <InfoRow label="Free VRAM" value={`${gpu.free_memory_mb} MB`} />
                <InfoRow label="Used VRAM" value={`${gpu.used_memory_mb} MB`} />
                <InfoRow label="Utilization" value={`${gpu.utilization_percent.toFixed(1)}%`} />
              </div>
            </div>
          ))}</div> : <p className="text-dark-500">No GPU detected</p>}
        </div>
        <div className="atlas-card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><HardDrive className="w-5 h-5 text-atlas-400" />Storage</h3>
          <div className="space-y-3">
            <InfoRow label="Total" value={`${profile?.storage.total_gb} GB`} />
            <InfoRow label="Free" value={`${profile?.storage.free_gb} GB`} />
            <InfoRow label="Used" value={`${(profile?.storage.total_gb || 0) - (profile?.storage.free_gb || 0)} GB`} />
          </div>
        </div>
        <div className="atlas-card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Activity className="w-5 h-5 text-atlas-400" />Operating System</h3>
          <div className="space-y-3">
            <InfoRow label="Name" value={profile?.os.name} />
            <InfoRow label="Version" value={profile?.os.version} />
            <InfoRow label="Architecture" value={profile?.os.architecture} />
          </div>
        </div>
        {resources && <div className="atlas-card">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Activity className="w-5 h-5 text-atlas-400" />Real-time Usage</h3>
          <div className="space-y-3">
            <InfoRow label="CPU Usage" value={`${resources.cpu_percent?.toFixed(1)}%`} />
            <InfoRow label="RAM Used" value={`${resources.ram_used_mb} MB`} />
            <InfoRow label="RAM Available" value={`${resources.ram_available_mb} MB`} />
          </div>
        </div>}
      </div>
    </div>
  )
}

function InfoRow({ label, value }: { label: string; value: any }) {
  return <div className="flex justify-between items-center"><span className="text-sm text-dark-500">{label}</span><span className="text-sm font-medium text-dark-200">{value || 'N/A'}</span></div>
}
