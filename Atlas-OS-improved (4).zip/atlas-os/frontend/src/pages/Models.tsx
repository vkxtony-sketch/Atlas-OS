import { useEffect, useState } from 'react'
import { Brain, Download, CheckCircle, XCircle, Microchip } from 'lucide-react'
import api from '../services/api'
import type { ModelInfo } from '../types'

export default function Models() {
  const [models, setModels] = useState<ModelInfo[]>([])
  const [recommendations, setRecommendations] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([api.getModels(), api.getRecommendations()]).then(([mRes, rRes]) => {
      if (mRes.success) setModels(mRes.models)
      if (rRes.success) setRecommendations(rRes.recommendations)
    }).finally(() => setLoading(false))
  }, [])

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <header className="mb-8"><h2 className="text-3xl font-bold text-white">Model Manager</h2><p className="text-dark-400 mt-1">AI models and hardware compatibility</p></header>
      {loading ? <div className="flex justify-center py-12"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-atlas-500" /></div> : (
        <div className="space-y-6">
          <div className="atlas-card">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Microchip className="w-5 h-5 text-atlas-400" />Hardware Compatibility</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {recommendations.map((rec) => (
                <div key={rec.id} className={`p-4 rounded-lg border ${rec.can_run ? 'bg-emerald-500/5 border-emerald-500/20' : 'bg-red-500/5 border-red-500/20'}`}>
                  <div className="flex items-center justify-between"><span className="font-medium text-dark-200">{rec.name}</span>{rec.can_run ? <CheckCircle className="w-5 h-5 text-emerald-400" /> : <XCircle className="w-5 h-5 text-red-400" />}</div>
                  <p className="text-xs text-dark-500 mt-1">Needs: {rec.required_ram_mb}MB RAM{rec.required_vram_mb > 0 ? `, ${rec.required_vram_mb}MB VRAM` : ''}</p>
                </div>
              ))}
            </div>
          </div>
          <div className="atlas-card">
            <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2"><Brain className="w-5 h-5 text-atlas-400" />Available Models</h3>
            <div className="space-y-3">
              {models.map((model) => (
                <div key={model.id} className="flex items-center justify-between p-4 rounded-lg bg-dark-800 border border-dark-700">
                  <div>
                    <div className="flex items-center gap-3">
                      <h4 className="font-medium text-dark-100">{model.name}</h4>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-dark-700 text-dark-400">{model.parameters}</span>
                      <span className="text-xs px-2 py-0.5 rounded-full bg-dark-700 text-dark-400 capitalize">{model.size}</span>
                    </div>
                    <p className="text-sm text-dark-500 mt-1">{model.description}</p>
                    <div className="flex gap-2 mt-2">{model.tags.map(tag => <span key={tag} className="text-xs text-atlas-400">#{tag}</span>)}</div>
                  </div>
                  <button className="atlas-button-outline flex items-center gap-2"><Download className="w-4 h-4" />Pull</button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
