const API_BASE = '/api/v1';

async function fetchJson(url: string, options?: RequestInit) {
  const response = await fetch(url, { ...options, headers: { 'Content-Type': 'application/json', ...options?.headers } });
  if (!response.ok) throw new Error(`HTTP ${response.status}: ${response.statusText}`);
  return response.json();
}

export const api = {
  health: () => fetchJson('/health'),
  getHardwareProfile: () => fetchJson(`${API_BASE}/hardware/profile`),
  getResources: () => fetchJson(`${API_BASE}/hardware/resources`),
  getModels: () => fetchJson(`${API_BASE}/models/registry`),
  getAvailableModels: () => fetchJson(`${API_BASE}/models/available`),
  getRecommendations: () => fetchJson(`${API_BASE}/models/recommendations`),
  listAgents: () => fetchJson(`${API_BASE}/agents/list`),
  getAgentStatus: (name: string) => fetchJson(`${API_BASE}/agents/${name}/status`),
  executeAgent: (name: string, task: string, context?: string, projectId?: string) => fetchJson(`${API_BASE}/agents/${name}/execute`, { method: 'POST', body: JSON.stringify({ task, context, project_id: projectId }) }),
  chat: (messages: any[], model?: string, stream = false) => fetchJson(`${API_BASE}/chat/completion`, { method: 'POST', body: JSON.stringify({ messages, model, stream }) }),
  generate: (prompt: string, model?: string, stream = false) => fetchJson(`${API_BASE}/chat/generate`, { method: 'POST', body: JSON.stringify({ prompt, model, stream }) }),
  searchKnowledge: (query: string, topK = 5) => fetchJson(`${API_BASE}/knowledge/search`, { method: 'POST', body: JSON.stringify({ query, top_k: topK }) }),
  getKbStats: () => fetchJson(`${API_BASE}/knowledge/stats`),
  listProjects: () => fetchJson(`${API_BASE}/projects/list`),
  getProject: (projectId: string) => fetchJson(`${API_BASE}/projects/${projectId}`),
  createProject: (name: string, description?: string, goal?: string) => fetchJson(`${API_BASE}/projects/create`, { method: 'POST', body: JSON.stringify({ name, description, goal }) }),
  processGoal: (goal: string, onEvent: (event: any) => void, projectId?: string) => {
    const qs = new URLSearchParams({ goal, ...(projectId ? { project_id: projectId } : {}) });
    const eventSource = new EventSource(`${API_BASE}/agents/executive/goal?${qs.toString()}`);
    eventSource.onmessage = (e) => { if (e.data === '[DONE]') eventSource.close(); else { try { onEvent(JSON.parse(e.data)); } catch { onEvent({ type: 'message', content: e.data }); } } };
    eventSource.onerror = () => eventSource.close();
    return () => eventSource.close();
  },
};

export default api;
