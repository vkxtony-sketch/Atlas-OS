# Atlas OS - AI Operating System

Atlas OS is an open-source, local-first, multi-agent AI task-completion system built on Ollama.

## How it works

1. You give it a goal (e.g. "add input validation to the signup form and write tests for it").
2. The **planner** asks the local LLM to break the goal into an ordered, dependency-aware list of steps, each assigned to a specialist agent. If the model's output isn't usable JSON, a keyword-based fallback plan is used instead.
3. **Independent steps run concurrently** (up to `ATLAS_MAX_CONCURRENCY` at once) instead of one at a time — steps only wait on the specific prior steps they declared as dependencies.
4. Each **agent** that needs to act on files/commands runs an iterative tool-use loop (think → call a tool → observe the result → repeat) rather than just generating text. Tool-using agents are: `coding`, `testing`, `documentation`, `security` (read-only), `git`, `terminal`, `deployment`, `performance`, and `knowledge`.
5. All file and shell access is confined to that project's own workspace directory (`data/workspaces/<project_id>`) and shell commands are restricted to an allowlist of developer tools — see `atlas/core/tools.py`. This is process-level sandboxing, not a full container/VM sandbox.
6. Once all steps finish, the **consensus engine** combines their outputs and three **reviewer passes** (security, performance, architecture) run *concurrently* against the combined result, each classifying findings as `critical` / `major` / `minor` / `suggestion`. Critical/major findings trigger an automatic **revision pass** (bounded by `ATLAS_MAX_REVISION_ROUNDS`) before the result ships; minor findings and suggestions are attached to the final output instead of blocking it.
7. The **quality scorer** checks the final result (e.g. it actually runs `ast.parse` on Python output rather than just checking for the substring `"def "`).

## Features

- **11 specialized agents**: coding, testing, security, documentation, research, knowledge, performance, git, deployment, terminal, executive
- **Model-agnostic**: works with any Ollama-compatible model
- **Hardware-aware**: auto-detects CPU/GPU/RAM and recommends models that will actually fit
- **Privacy-first, local-only**: no cloud calls; all data and inference stay on your machine
- **Knowledge base**: ChromaDB vector store for document RAG, used by the `research` and `knowledge` agents

## Honest limitations

- Planning and tool-use quality depend heavily on which local model you run. Small models (3B) will follow the ReAct tool format and review-JSON format less reliably than larger ones (7B+). Point `ATLAS_REVIEW_MODEL` / `ATLAS_PLANNER_MODEL` at a capable model for best results.
- This orchestration approach narrows the gap to frontier hosted models for well-scoped, reviewable software tasks — it does not make local 7B–70B models equal to frontier models on raw general reasoning. Don't expect it to "beat" a top hosted model at, say, an open-ended research question with no local evidence to ground it.
- The command sandbox is an allowlist + path confinement, not a container. If you want to run genuinely untrusted or complex builds, run Atlas OS itself inside Docker/a VM.
- There's no live internet access; the `research` agent grounds itself in your local knowledge base only.
- The revision loop calls out to the same local model repeatedly; on modest hardware, more revision rounds and more reviewers trade speed for quality. Tune `ATLAS_MAX_REVISION_ROUNDS` and `ATLAS_MAX_CONCURRENCY` to your machine.

## Prerequisites

- Python 3.10+
- [Ollama](https://ollama.com) installed and running, with at least one model pulled (e.g. `ollama pull llama3.2`)
- Node.js 20+ (for frontend build)

## Quick Start

### Backend
```bash
cd backend
pip install -r requirements.txt
cp .env.example .env
python scripts/generate_api_key.py
python -m uvicorn atlas.main:app --host 127.0.0.1 --port 8472
```

Every `/api/v1/*` route now requires an `Authorization: Bearer <your-key>` header (the key printed by the script above). `/health` stays open so you can smoke-test the server without a key. For pure local dev on a trusted machine you can set `ATLAS_AUTH_ENABLED=false` in `.env` to skip auth entirely.

### Frontend
```bash
cd frontend
npm install
npm run build
```

### Desktop App (.exe)
```bash
cd desktop
pip install pyinstaller pywebview
pyinstaller build.spec
```

Or simply run `build.bat` (Windows) or `python build.py` (cross-platform).

## Architecture

| Layer | Technology |
|-------|-----------|
| Frontend | React 19 + TypeScript + Tailwind CSS |
| Backend | Python FastAPI |
| AI Engine | Ollama integration, ReAct-style tool-use loop |
| Knowledge | ChromaDB vector store |
| Desktop | PyInstaller + webview |

## Configuration

Environment variables (all optional):

| Variable | Default | Purpose |
|---|---|---|
| `ATLAS_OLLAMA_HOST` | `http://127.0.0.1:11434` | Ollama server URL |
| `ATLAS_API_PORT` | `8472` | Backend port |
| `ATLAS_WORKSPACE_DIR` | `backend/data/workspaces` | Root directory for per-project sandboxes |
| `ATLAS_PLANNER_MODEL` | `llama3.2` | Model used to decompose goals into plans |
| `ATLAS_AGENT_MAX_ITERATIONS` | `6` | Max think/act steps per agent per task |
| `ATLAS_REVIEW_MODEL` | `llama3.2` | Model used for security/performance/architecture review passes |
| `ATLAS_MAX_REVISION_ROUNDS` | `1` | Max automatic revision passes when reviewers flag critical/major issues |
| `ATLAS_MAX_CONCURRENCY` | `1` | Max plan steps / reviewer calls running against Ollama at once |
| `ATLAS_BRAND_NAME` | `Atlas OS` | Name shown in API docs, /health, and responses |
| `ATLAS_BRAND_TAGLINE` | see .env.example | Shown in API docs |
| `ATLAS_BRAND_SYSTEM_PROMPT` | see .env.example | Prepended as system message on every /chat call unless caller supplies their own |
| `ATLAS_AUTH_ENABLED` | `true` | Require an API key on all /api/v1/* routes |
| `ATLAS_API_KEYS` | empty | Comma-separated valid keys, in addition to backend/data/api_keys.txt |
| `ATLAS_RATE_LIMIT_PER_MINUTE` | `20` | Requests allowed per key per rolling 60s window |

The concurrency/revision defaults above are deliberately conservative for CPU-only hardware with no dedicated GPU (about 12GB RAM, no AVX2) -- check GET /api/v1/hardware/profile for a live recommended_concurrency and raise these once you've confirmed your box can take it.

## Branding and running this as your own API

This is meant to be self-hosted and put behind your own name:

1. Set ATLAS_BRAND_NAME, ATLAS_BRAND_TAGLINE, and ATLAS_BRAND_SYSTEM_PROMPT in .env.
2. Mint API keys for whichever apps/clients you want to allow: python scripts/generate_api_key.py (label). Keys live in backend/data/api_keys.txt (gitignored) and are picked up live, no restart needed.
3. Every response from /chat/completion and /chat/generate includes your brand name and the model that answered, so clients can display or log it.
4. Rate limiting is per-key (ATLAS_RATE_LIMIT_PER_MINUTE), not global, so one client can't starve another.

Fine-tuning roadmap (later, not on this box): local CPU-only hardware can serve a small quantized model but can't realistically train one. When you're ready, rent a GPU (RunPod, Lambda Labs, etc.), LoRA/QLoRA fine-tune a small open model (e.g. Llama 3.2 3B) on your own data, quantize the result to GGUF, and drop it into Ollama via a custom Modelfile -- your branded API surface above doesn't need to change at all, just the model name you point it at.

## Multi-model debate for coding tasks

Coding steps no longer trust a single model's first answer. When `ATLAS_DEBATE_ENABLED=true` (default):

1. Every model in `ATLAS_DEBATE_MODELS` (default: `llama3.2,qwen2.5,mistral` -- all free, local, already in your model registry) independently solves the exact same task, with no visibility into each other.
2. Each model is then shown the others' solutions -- anonymized as "Solution A/B/C" so it can't just defer to a model it recognizes -- and asked to critique them and write its own best revision.
3. After each round, candidates are compared for similarity. If they've converged (agreement score above `ATLAS_DEBATE_AGREEMENT_THRESHOLD`), the debate stops early; otherwise it repeats up to `ATLAS_DEBATE_MAX_ROUNDS`.
4. If they never fully converge, a judge pass (`ATLAS_REVIEW_MODEL`) reconciles the strongest candidate rather than shipping something no model actually agreed to.
5. Only then is the finished, agreed-upon code written into the project workspace.

You (and the frontend, if you build it in) only see the final finished product -- the back-and-forth is available in each step's `debate` field (`converged`, `agreement_score`, `rounds`, `participants`) if you want to show or log it.

**Performance note:** models run one at a time, not concurrently -- see the comment in `atlas/config.py`. On CPU-only hardware, 3 models x up to 3 rounds means a coding step can take a while. Trim `ATLAS_DEBATE_MODELS` to 2 models or lower `ATLAS_DEBATE_MAX_ROUNDS` if it's too slow; the debate quality/speed tradeoff is yours to tune.

## Working until it's actually done

A single plan -> build -> review pass often isn't enough to get something right. Atlas now wraps the whole thing in a loop: after review/revision, it checks the result's quality score and whether any blocking issues remain. If it's not good enough, it re-plans with the accumulated feedback folded in and tries again -- up to `ATLAS_MAX_PROJECT_ITERATIONS` times (default 3) -- instead of stopping after one attempt. The final `complete` event reports how many iterations and revision rounds it took.

## Clarifying questions

Before planning, Atlas asks its own planner model whether your goal is specified well enough to build without guessing (missing language/framework, ambiguous scope, etc). If not, the `GET /api/v1/agents/executive/goal` stream ends early with a `clarification_needed` event containing up to `ATLAS_CLARIFY_MAX_QUESTIONS` questions -- no plan runs yet. Answer them and re-call the same endpoint with a `clarifications` query param (a JSON object mapping each question to your answer) to resume with that context included. Set `ATLAS_CLARIFY_ENABLED=false` to always have it make its own assumptions instead.

## Memory system

Atlas carries two kinds of state across goals and sessions (`atlas/core/memory.py`), backed by the same local SQLite file as your projects:

- **User preferences** -- global key/value settings (e.g. `test_framework=pytest`, `code_style=minimal_comments`) that get folded into every plan automatically, so you don't have to repeat them in every goal. Manage them via `GET/POST /api/v1/memory/preferences` and `DELETE /api/v1/memory/preferences/{key}`.
- **Project history** -- a timestamped event log per project. Every completed goal is recorded automatically (`goal` events with quality score and iteration count), and anything the architecture reviewer flags gets logged as an `architecture_note`, so a later goal on the same project has context on what was already built, tried, or flagged -- instead of Atlas re-deciding things from scratch or contradicting an earlier choice. View it via `GET /api/v1/memory/projects/{project_id}/history`, or record your own decisions manually with `POST /api/v1/memory/projects/{project_id}/history` (body: `{"event_type": "decision", "summary": "..."}`).

To use this, pass `project_id` on `GET /api/v1/agents/executive/goal` -- relevant preferences and recent history are loaded and prepended to the goal before planning starts, and you'll see a `memory_loaded` event in the stream when that happens.

## License

MIT

