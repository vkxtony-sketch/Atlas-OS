"""Atlas OS Desktop Launcher"""
import subprocess
import sys
import os
import time
import webbrowser
import threading

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKEND_DIR = os.path.join(BASE_DIR, "backend")
FRONTEND_DIR = os.path.join(BASE_DIR, "frontend")

server_process = None

def start_backend():
    global server_process
    print("Starting Atlas OS backend...")
    env = os.environ.copy()
    env["PYTHONPATH"] = BACKEND_DIR
    server_process = subprocess.Popen(
        [sys.executable, "-m", "uvicorn", "atlas.main:app", "--host", "127.0.0.1", "--port", "8472"],
        cwd=BACKEND_DIR,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    time.sleep(3)
    print("Backend started on http://127.0.0.1:8472")

def open_browser():
    time.sleep(4)
    url = "http://127.0.0.1:8472"
    try:
        import webview
        webview.create_window("Atlas OS", url, width=1400, height=900)
        webview.start()
    except ImportError:
        webbrowser.open(url)

if __name__ == "__main__":
    start_backend()
    open_browser()
    if server_process:
        server_process.terminate()
