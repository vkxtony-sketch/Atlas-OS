"""Atlas OS Build Script"""
import subprocess
import sys
import os

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def run(cmd, cwd=None):
    print(f">>> {cmd}")
    env = os.environ.copy()
    env["PYO3_USE_ABI3_FORWARD_COMPATIBILITY"] = "1"
    result = subprocess.run(cmd, shell=True, cwd=cwd or BASE_DIR, env=env)
    if result.returncode != 0:
        print(f"FAILED: {cmd}")
        sys.exit(1)


print("=" * 60)
print("  Atlas OS Build Script")
print("=" * 60)

py_version = sys.version_info
print(f"\nPython version: {py_version.major}.{py_version.minor}.{py_version.micro}")

print("\n[1/4] Installing Python dependencies...")
run("pip install -r backend/requirements.txt", cwd=os.path.join(BASE_DIR, "backend"))

print("\n[2/4] Building frontend...")
frontend_dir = os.path.join(BASE_DIR, "frontend")
run("npm install", cwd=frontend_dir)
run("npm run build", cwd=frontend_dir)

print("\n[3/4] Building executable...")
desktop_dir = os.path.join(BASE_DIR, "desktop")
run("pip install pyinstaller pywebview", cwd=desktop_dir)
run("pyinstaller build.spec", cwd=desktop_dir)

print("\n[4/4] Finalizing...")
dist_dir = os.path.join(desktop_dir, "dist")
if os.path.exists(dist_dir):
    print("\nBuild complete! Executable is at:")
    print(f"  {os.path.join(dist_dir, 'Atlas-OS.exe')}")
else:
    print("\nBuild may have failed. Check output above.")

print("\nDone!")
